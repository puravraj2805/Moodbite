import React from 'react';
import { Brain, Heart, Users, Zap, Award, Target, Globe, Shield } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-orange-500 to-purple-600 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Meet MoodBites AI
            </h1>
            <p className="text-xl md:text-2xl text-orange-100 mb-8 leading-relaxed">
              The most intelligent food recommendation agent that understands your mood, 
              preferences, and context to find your perfect dining experience.
            </p>
            <div className="flex items-center justify-center space-x-6 text-orange-100">
              <div className="flex items-center space-x-2">
                <Brain className="w-6 h-6" />
                <span>AI-Powered</span>
              </div>
              <div className="flex items-center space-x-2">
                <Heart className="w-6 h-6" />
                <span>Made with Love</span>
              </div>
              <div className="flex items-center space-x-2">
                <Users className="w-6 h-6" />
                <span>25K+ Happy Users</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mission Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-gray-800 mb-6">Our Mission</h2>
            <p className="text-xl text-gray-600 leading-relaxed mb-8">
              We believe that finding the perfect restaurant shouldn't be a guessing game. 
              MoodBites AI combines advanced machine learning with real-world dining data 
              to help you discover amazing food experiences that match your exact mood and preferences.
            </p>
            <div className="bg-gradient-to-r from-orange-50 to-purple-50 rounded-2xl p-8">
              <blockquote className="text-2xl font-medium text-gray-800 italic">
                "Every meal is an opportunity for joy. Our AI ensures you never miss that opportunity."
              </blockquote>
              <cite className="text-lg text-gray-600 mt-4 block">— The MoodBites Team</cite>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              The Science Behind MoodBites
            </h2>
            <p className="text-xl text-gray-600">
              Advanced AI technology meets culinary expertise
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Smart Analysis</h3>
              <p className="text-gray-600">
                Our AI analyzes 50+ preference factors to understand your unique dining personality
              </p>
            </div>

            <div className="text-center bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Multi-Source Data</h3>
              <p className="text-gray-600">
                We aggregate data from Google Reviews, Pinterest, Reddit, and social media for comprehensive insights
              </p>
            </div>

            <div className="text-center bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Real-Time Learning</h3>
              <p className="text-gray-600">
                Our AI continuously learns from your choices to provide increasingly accurate recommendations
              </p>
            </div>

            <div className="text-center bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Precision Matching</h3>
              <p className="text-gray-600">
                98% accuracy rate in matching users with restaurants they'll love based on their criteria
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Deep Dive */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              Why MoodBites is Different
            </h2>
            <p className="text-xl text-gray-600">
              Features that make us the smartest food recommendation agent
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-pink-400 to-pink-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Mood-Based Recommendations</h3>
                  <p className="text-gray-600">
                    We don't just consider what you like—we understand how you're feeling and what experience you're seeking.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-indigo-400 to-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Inclusive & Thoughtful</h3>
                  <p className="text-gray-600">
                    From LGBTQ+ friendly venues to pet-friendly patios, we consider all aspects of your identity and needs.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Voice-Powered Interaction</h3>
                  <p className="text-gray-600">
                    Talk to our AI naturally—no typing required. Get recommendations through conversation.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">Privacy First</h3>
                  <p className="text-gray-600">
                    Your preferences and conversations are private. We learn to serve you better while protecting your data.
                  </p>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="bg-gradient-to-br from-orange-100 to-purple-100 rounded-2xl p-8 text-center">
                <div className="w-32 h-32 bg-gradient-to-r from-orange-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Brain className="w-16 h-16 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">
                  Advanced AI Engine
                </h3>
                <p className="text-gray-600 mb-6">
                  Powered by cutting-edge machine learning algorithms that process millions of data points in real-time.
                </p>
                <div className="space-y-3">
                  <div className="bg-white rounded-lg p-3 flex items-center justify-between">
                    <span className="text-gray-700">Natural Language Processing</span>
                    <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                  </div>
                  <div className="bg-white rounded-lg p-3 flex items-center justify-between">
                    <span className="text-gray-700">Contextual Understanding</span>
                    <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                  </div>
                  <div className="bg-white rounded-lg p-3 flex items-center justify-between">
                    <span className="text-gray-700">Predictive Analytics</span>
                    <div className="w-4 h-4 bg-green-500 rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Awards & Recognition */}
      <section className="py-16 bg-gradient-to-br from-gray-800 to-gray-900 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Awards & Recognition</h2>
            <p className="text-xl text-gray-300">
              Recognized by industry leaders for innovation in AI and food technology
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center bg-white bg-opacity-10 rounded-xl p-6 backdrop-blur-sm">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Best AI Innovation 2024</h3>
              <p className="text-gray-300">Food Tech Awards</p>
            </div>

            <div className="text-center bg-white bg-opacity-10 rounded-xl p-6 backdrop-blur-sm">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">People's Choice Winner</h3>
              <p className="text-gray-300">Tech Startup Awards</p>
            </div>

            <div className="text-center bg-white bg-opacity-10 rounded-xl p-6 backdrop-blur-sm">
              <div className="w-16 h-16 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-2">Top 10 AI Startups</h3>
              <p className="text-gray-300">VentureBeat Recognition</p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Values */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-red-400 to-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Passion for Food</h3>
              <p className="text-gray-600">
                We're food lovers first, technologists second. Every recommendation comes from genuine enthusiasm for great dining.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Inclusivity</h3>
              <p className="text-gray-600">
                Food brings people together. We ensure everyone finds their perfect dining experience, regardless of background or needs.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Innovation</h3>
              <p className="text-gray-600">
                We push the boundaries of what's possible with AI to create experiences that feel magical, not mechanical.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">Trust</h3>
              <p className="text-gray-600">
                Your data is sacred, your privacy paramount. We earn your trust through transparency and responsible AI practices.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-gradient-to-r from-orange-500 to-purple-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Transform Your Dining?</h2>
          <p className="text-xl text-orange-100 mb-8 max-w-2xl mx-auto">
            Join thousands of food lovers who've discovered their new favorite restaurants with MoodBites AI.
          </p>
          <button className="bg-white text-gray-800 px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-100 transition-colors duration-300">
            Start Your Food Journey
          </button>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;