import React, { useState } from 'react';
import DynamicRecommendations from '../components/DynamicRecommendations';
import { UserPreferences, Restaurant } from '../types';
import { Search, Filter, MapPin, Star, Clock, TrendingUp } from 'lucide-react';

interface RecommendationsPageProps {
  preferences: UserPreferences | null;
  onGetDirections: (restaurant: Restaurant) => void;
  onStartPreferences: () => void;
}

const RecommendationsPage: React.FC<RecommendationsPageProps> = ({ 
  preferences, 
  onGetDirections,
  onStartPreferences 
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  if (!preferences) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-purple-50 to-green-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-8">
          <div className="w-24 h-24 bg-gradient-to-r from-orange-400 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Search className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-gray-800 mb-4">
            Start Your Food Journey
          </h2>
          <p className="text-gray-600 mb-8 leading-relaxed">
            To get personalized restaurant recommendations, please share your preferences with our AI assistant first.
          </p>
          <button
            onClick={onStartPreferences}
            className="bg-gradient-to-r from-orange-500 to-purple-600 hover:from-orange-600 hover:to-purple-700 text-white px-8 py-4 rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
          >
            Set Your Preferences
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Section */}
      <div className="bg-gradient-to-r from-orange-500 to-purple-600 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Your Personalized Recommendations
            </h1>
            <p className="text-xl text-orange-100 mb-8 max-w-2xl mx-auto">
              Discover amazing restaurants tailored to your preferences, powered by advanced AI
            </p>
          </div>
        </div>
      </div>

      {/* Preferences Summary */}
      <div className="bg-white border-b border-gray-200 py-6">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-sm">{preferences.numberOfPeople}</span>
                </div>
                <span className="text-gray-700 font-medium">People</span>
              </div>
              
              {preferences.occasion && (
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                    <Star className="w-4 h-4 text-purple-600" />
                  </div>
                  <span className="text-gray-700">{preferences.occasion}</span>
                </div>
              )}
              
              {preferences.foodType && (
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                    <span className="text-green-600 text-xs font-bold">🍽️</span>
                  </div>
                  <span className="text-gray-700">{preferences.foodType}</span>
                </div>
              )}
              
              {preferences.budget && (
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                    <span className="text-yellow-600 font-bold text-sm">{preferences.budget}</span>
                  </div>
                  <span className="text-gray-700">Budget</span>
                </div>
              )}
            </div>
            
            <button
              onClick={onStartPreferences}
              className="bg-gradient-to-r from-orange-500 to-purple-600 text-white px-6 py-2 rounded-full text-sm font-medium hover:from-orange-600 hover:to-purple-700 transition-all duration-300"
            >
              Update Preferences
            </button>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="bg-white py-8 border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <Filter className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800">150+</h3>
              <p className="text-sm text-gray-600">Matched Restaurants</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800">2.5mi</h3>
              <p className="text-sm text-gray-600">Average Distance</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <Star className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800">4.6</h3>
              <p className="text-sm text-gray-600">Average Rating</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800">18min</h3>
              <p className="text-sm text-gray-600">Avg Travel Time</p>
            </div>
          </div>
        </div>
      </div>

      {/* Dynamic Recommendations */}
      <DynamicRecommendations 
        preferences={preferences}
        onGetDirections={onGetDirections}
        searchQuery={searchQuery}
      />

      {/* Trending Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <TrendingUp className="w-6 h-6 text-orange-500" />
              <h2 className="text-3xl font-bold text-gray-800">Trending Now</h2>
            </div>
            <p className="text-xl text-gray-600">
              Popular restaurants based on real-time social media buzz
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl p-6 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-red-400 to-red-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">📍</span>
                </div>
                <div>
                  <h3 className="font-bold text-gray-800">Pinterest Favorites</h3>
                  <p className="text-sm text-gray-600">Most pinned restaurants</p>
                </div>
              </div>
              <p className="text-gray-700">Visually stunning restaurants perfect for your Instagram feed</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-6 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">🏆</span>
                </div>
                <div>
                  <h3 className="font-bold text-gray-800">Reddit Gems</h3>
                  <p className="text-sm text-gray-600">Community favorites</p>
                </div>
              </div>
              <p className="text-gray-700">Hidden gems discovered by local food enthusiasts</p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-6 hover:shadow-lg transition-all duration-300">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold">⭐</span>
                </div>
                <div>
                  <h3 className="font-bold text-gray-800">Google Top Rated</h3>
                  <p className="text-sm text-gray-600">Highest reviewed</p>
                </div>
              </div>
              <p className="text-gray-700">Consistently highly rated restaurants with exceptional service</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default RecommendationsPage;