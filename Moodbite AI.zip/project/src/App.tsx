import React, { useState } from 'react';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import RecommendationsPage from './pages/RecommendationsPage';
import AboutPage from './pages/AboutPage';
import PreferencesForm from './components/PreferencesForm';
import SmartChatbot from './components/SmartChatbot';
import DirectionsModal from './components/DirectionsModal';
import { Heart, Brain, Users, Star, Sparkles, Phone, Mail, Shield, ChefHat } from 'lucide-react';
import { UserPreferences, Restaurant } from './types';

function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'recommendations' | 'about'>('home');
  const [showPreferences, setShowPreferences] = useState(false);
  const [userPreferences, setUserPreferences] = useState<UserPreferences | null>(null);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [showDirections, setShowDirections] = useState(false);

  const handlePreferencesSubmit = (preferences: UserPreferences) => {
    setUserPreferences(preferences);
    setShowPreferences(false);
    setCurrentPage('recommendations');
  };

  const handleGetDirections = (restaurant: Restaurant) => {
    setSelectedRestaurant(restaurant);
    setShowDirections(true);
  };

  const handleStartPreferences = () => {
    setShowPreferences(true);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onStartClick={handleStartPreferences} />;
      case 'recommendations':
        return (
          <RecommendationsPage 
            preferences={userPreferences}
            onGetDirections={handleGetDirections}
            onStartPreferences={handleStartPreferences}
          />
        );
      case 'about':
        return <AboutPage />;
      default:
        return <HomePage onStartClick={handleStartPreferences} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onChatToggle={() => setIsChatOpen(!isChatOpen)}
        isChatOpen={isChatOpen}
      />
      
      <main>
        {renderCurrentPage()}
      </main>

      {/* Modals and Overlays */}
      {showPreferences && (
        <PreferencesForm
          onSubmit={handlePreferencesSubmit}
          onClose={() => setShowPreferences(false)}
        />
      )}

      <SmartChatbot 
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        userPreferences={userPreferences}
        onGetDirections={handleGetDirections}
        onPreferencesUpdate={(updates) => {
          if (userPreferences) {
            setUserPreferences({ ...userPreferences, ...updates });
          }
        }}
      />

      <DirectionsModal
        restaurant={selectedRestaurant}
        isOpen={showDirections}
        onClose={() => setShowDirections(false)}
      />

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white py-16 mt-16 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 bg-gradient-to-r from-orange-500/5 to-purple-600/5"></div>
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 via-purple-500 to-green-500"></div>
        
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 relative z-10">
            {/* Brand Section */}
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="bg-gradient-to-r from-orange-500 to-purple-600 p-3 rounded-2xl shadow-lg">
                  <ChefHat className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold bg-gradient-to-r from-orange-400 to-purple-500 bg-clip-text text-transparent">
                    MoodBites
                  </h3>
                  <div className="flex items-center space-x-1 text-xs text-gray-400">
                    <Brain className="w-3 h-3" />
                    <span>AI Food Agent</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed mb-6 text-lg">
                Your AI-powered dining companion, helping you discover the perfect restaurant for every mood and occasion.
              </p>
              
              {/* Social proof */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-white/5 rounded-lg p-3 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center space-x-2">
                    <Users className="w-5 h-5 text-blue-400" />
                    <div>
                      <p className="font-bold text-white">25K+</p>
                      <p className="text-xs text-gray-400">Happy Users</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white/5 rounded-lg p-3 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center space-x-2">
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <div>
                      <p className="font-bold text-white">4.9/5</p>
                      <p className="text-xs text-gray-400">Rating</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Features Section */}
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <Sparkles className="w-6 h-6 text-purple-400" />
                <h4 className="font-bold text-xl text-white">Features</h4>
              </div>
              <ul className="space-y-3">
                <li className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors group">
                  <div className="w-2 h-2 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full group-hover:scale-125 transition-transform"></div>
                  <span>Personalized Recommendations</span>
                </li>
                <li className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors group">
                  <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full group-hover:scale-125 transition-transform"></div>
                  <span>Voice Assistant</span>
                </li>
                <li className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors group">
                  <div className="w-2 h-2 bg-gradient-to-r from-green-400 to-green-600 rounded-full group-hover:scale-125 transition-transform"></div>
                  <span>Real-time Directions</span>
                </li>
                <li className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors group">
                  <div className="w-2 h-2 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full group-hover:scale-125 transition-transform"></div>
                  <span>Smart Filtering</span>
                </li>
                <li className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors group">
                  <div className="w-2 h-2 bg-gradient-to-r from-pink-400 to-pink-600 rounded-full group-hover:scale-125 transition-transform"></div>
                  <span>Multi-Source Data</span>
                </li>
              </ul>
            </div>
            
            {/* Contact Section */}
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <Phone className="w-6 h-6 text-green-400" />
                <h4 className="font-bold text-xl text-white">Contact</h4>
              </div>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors group">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Mail className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-medium">hello@moodbites.com</p>
                    <p className="text-sm text-gray-400">Email us anytime</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3 text-gray-300 hover:text-white transition-colors group">
                  <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-green-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Phone className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-medium">(555) 123-BITE</p>
                    <p className="text-sm text-gray-400">Available 24/7</p>
                  </div>
                </div>
                
                <div className="bg-white/5 rounded-lg p-3 backdrop-blur-sm border border-white/10">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-sm font-medium text-green-400">AI Assistant Online</span>
                  </div>
                  <p className="text-xs text-gray-400">Ready to help you find great food!</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Bottom Section */}
          <div className="border-t border-gray-700/50 mt-12 pt-8 relative z-10">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
              <div className="flex items-center space-x-4">
                <p className="text-gray-400 text-sm">
                  &copy; 2025 MoodBites. Made with 
                  <Heart className="w-4 h-4 text-red-500 fill-current inline mx-1" />
                  for food lovers everywhere.
                </p>
              </div>
              
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2 text-xs text-gray-500">
                  <Brain className="w-4 h-4" />
                  <span>Powered by Advanced AI</span>
                </div>
                <div className="flex items-center space-x-2 text-xs text-gray-500">
                  <Shield className="w-4 h-4" />
                  <span>Privacy Protected</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;