import { useState, useCallback, useRef, useEffect } from 'react';
import { ChatMessage, UserPreferences, Restaurant, AIPersonality } from '../types';

export const useAIAgent = () => {
  const [personality] = useState<AIPersonality>({
    name: 'MoodBot',
    mood: 'enthusiastic',
    expertise: ['fine dining', 'casual eats', 'cultural cuisine', 'dietary restrictions'],
    conversationStyle: 'friendly'
  });

  const [isLearning, setIsLearning] = useState(false);
  const [contextMemory, setContextMemory] = useState<Record<string, any>>({});
  const conversationDepth = useRef(0);

  const analyzeUserIntent = useCallback((message: string): {
    intent: string;
    entities: string[];
    confidence: number;
  } => {
    const lowercaseMsg = message.toLowerCase();
    
    // Intent classification
    if (lowercaseMsg.includes('recommend') || lowercaseMsg.includes('suggest') || lowercaseMsg.includes('find')) {
      return { intent: 'request_recommendation', entities: extractFoodEntities(message), confidence: 0.9 };
    }
    if (lowercaseMsg.includes('budget') || lowercaseMsg.includes('cheap') || lowercaseMsg.includes('expensive')) {
      return { intent: 'budget_query', entities: extractBudgetEntities(message), confidence: 0.8 };
    }
    if (lowercaseMsg.includes('location') || lowercaseMsg.includes('near') || lowercaseMsg.includes('around')) {
      return { intent: 'location_query', entities: extractLocationEntities(message), confidence: 0.85 };
    }
    if (lowercaseMsg.includes('cuisine') || lowercaseMsg.includes('food') || lowercaseMsg.includes('restaurant')) {
      return { intent: 'cuisine_query', entities: extractFoodEntities(message), confidence: 0.75 };
    }
    
    return { intent: 'general_chat', entities: [], confidence: 0.6 };
  }, []);

  const extractFoodEntities = (message: string): string[] => {
    const cuisines = ['italian', 'chinese', 'mexican', 'indian', 'japanese', 'thai', 'french', 'american', 'mediterranean'];
    const foods = ['pizza', 'sushi', 'burger', 'pasta', 'tacos', 'curry', 'noodles', 'salad', 'steak'];
    const entities: string[] = [];
    
    [...cuisines, ...foods].forEach(entity => {
      if (message.toLowerCase().includes(entity)) {
        entities.push(entity);
      }
    });
    
    return entities;
  };

  const extractBudgetEntities = (message: string): string[] => {
    const budgetKeywords = ['cheap', 'affordable', 'expensive', 'luxury', 'budget', 'under', 'around', '$'];
    return budgetKeywords.filter(keyword => message.toLowerCase().includes(keyword));
  };

  const extractLocationEntities = (message: string): string[] => {
    const locationKeywords = ['near', 'around', 'downtown', 'uptown', 'mall', 'area', 'neighborhood'];
    return locationKeywords.filter(keyword => message.toLowerCase().includes(keyword));
  };

  const generateContextualResponse = useCallback((
    intent: string,
    entities: string[],
    userPreferences?: UserPreferences,
    previousMessages?: ChatMessage[]
  ): string => {
    conversationDepth.current += 1;
    
    const responses = {
      request_recommendation: [
        `I'm excited to help you find the perfect dining spot! 🍽️ Based on what you've told me, I'm thinking of some amazing options.`,
        `Let me work my food magic! ✨ I have some fantastic recommendations brewing for you.`,
        `Ooh, this is my favorite part! 🤤 I'm already imagining the perfect restaurants for your mood.`,
      ],
      budget_query: [
        `Let's talk budget! 💰 I know some incredible spots across all price ranges.`,
        `Budget-wise dining is my specialty! I can find gems from $ to $$$$ that'll blow your mind.`,
        `Money matters, and I've got you covered! Tell me your range and I'll work wonders.`,
      ],
      location_query: [
        `Location, location, location! 📍 I know the food scene like the back of my digital hand.`,
        `Perfect! I'm already mapping out the best spots in your area. Where exactly are you thinking?`,
        `I love local food hunting! 🗺️ Each neighborhood has its own culinary personality.`,
      ],
      cuisine_query: [
        `Cuisine talk - now we're getting into the delicious details! 🌮🍜🍕`,
        `Food types are my language! Every cuisine tells a story, and I know them all.`,
        `Mmm, let's dive into flavors! What's calling to your taste buds today?`,
      ],
      general_chat: [
        `I'm here and ready to be your personal food detective! What's on your mind? 🕵️‍♂️🍴`,
        `Hey there, foodie! I'm buzzing with restaurant knowledge. How can I help satisfy your cravings?`,
        `Welcome to your personal dining concierge service! I'm all ears... er, algorithms! 👂`,
      ]
    };

    // Add contextual elements
    let response = responses[intent as keyof typeof responses]?.[
      Math.floor(Math.random() * responses[intent as keyof typeof responses].length)
    ] || responses.general_chat[0];

    // Add personalization based on entities and preferences
    if (entities.length > 0) {
      const entityMention = entities.join(', ');
      response += ` I noticed you mentioned ${entityMention} - that gives me some great ideas!`;
    }

    if (userPreferences) {
      if (conversationDepth.current > 3) {
        response += ` Since you're dining with ${userPreferences.numberOfPeople} people, I'm keeping that in mind.`;
      }
    }

    // Add conversation flow
    if (conversationDepth.current === 1) {
      response += ` This is going to be fun - I love a good food challenge! 🎯`;
    } else if (conversationDepth.current > 5) {
      response += ` I'm really getting to know your taste preferences now! 🧠`;
    }

    return response;
  }, []);

  const learnFromInteraction = useCallback((
    userMessage: string,
    userPreferences?: UserPreferences,
    selectedRestaurants?: Restaurant[]
  ) => {
    setIsLearning(true);
    
    // Simulate learning delay
    setTimeout(() => {
      setContextMemory(prev => ({
        ...prev,
        lastInteraction: new Date(),
        messageCount: (prev.messageCount || 0) + 1,
        preferences: {
          ...prev.preferences,
          ...userPreferences
        },
        commonKeywords: [
          ...(prev.commonKeywords || []),
          ...userMessage.toLowerCase().split(' ').filter(word => word.length > 3)
        ].slice(-20) // Keep last 20 keywords
      }));
      
      setIsLearning(false);
    }, 800);
  }, []);

  const generateSmartRecommendations = useCallback((
    preferences: UserPreferences,
    conversationContext?: ChatMessage[]
  ): Restaurant[] => {
    // Enhanced AI-powered restaurant generation
    const baseRestaurants: Restaurant[] = [
      {
        id: '1',
        name: 'The Garden Bistro',
        rating: 4.8,
        cuisine: preferences.foodType || 'Mediterranean',
        priceRange: preferences.budget || '$$',
        address: '123 Main St, Downtown',
        image: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Outdoor Seating', 'Live Music', 'LGBTQ+ Friendly', 'Pet Friendly'],
        distance: '0.5 mi',
        estimatedTime: '15 min',
        aiScore: 95,
        matchReasons: ['Perfect for your occasion', 'Matches cuisine preference', 'Within budget range'],
        popularityTrend: 'up',
        aiInsights: 'Perfect match! Great for outdoor dining with live music ambience.'
      },
      {
        id: '2',
        name: 'Spice Route',
        rating: 4.6,
        cuisine: 'Indian',
        priceRange: '$$$',
        address: '456 Oak Ave, Midtown',
        image: 'https://images.pexels.com/photos/1579739/pexels-photo-1579739.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Kids Menu', 'Good Drinks', 'Date Night', 'Highly Rated'],
        distance: '1.2 mi',
        estimatedTime: '20 min',
        aiScore: 88,
        matchReasons: ['Family-friendly option', 'Excellent drink selection', 'High customer satisfaction'],
        popularityTrend: 'stable',
        aiInsights: 'Authentic Indian cuisine with excellent family atmosphere.'
      },
      {
        id: '3',
        name: 'Coastal Catch',
        rating: 4.7,
        cuisine: 'Seafood',
        priceRange: '$$$$',
        address: '789 Beach Rd, Waterfront',
        image: 'https://images.pexels.com/photos/696218/pexels-photo-696218.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Ocean View', 'Fresh Seafood', 'Romantic', 'Wine Selection'],
        distance: '2.1 mi',
        estimatedTime: '25 min',
        aiScore: 92,
        matchReasons: ['Premium dining experience', 'Perfect for special occasions', 'Stunning ocean views'],
        popularityTrend: 'up',
        aiInsights: 'Upscale seafood with breathtaking waterfront views.'
      },
      {
        id: '4',
        name: 'Urban Eats',
        rating: 4.5,
        cuisine: 'American',
        priceRange: '$$',
        address: '321 City Plaza, Central',
        image: 'https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Family Friendly', 'Quick Service', 'All Ages', 'Local Favorite'],
        distance: '0.8 mi',
        estimatedTime: '18 min',
        aiScore: 85,
        matchReasons: ['Great value proposition', 'Family-friendly atmosphere', 'Convenient location'],
        popularityTrend: 'stable',
        aiInsights: 'Reliable American classics with great value for families.'
      },
      {
        id: '5',
        name: 'Sakura Sushi',
        rating: 4.9,
        cuisine: 'Japanese',
        priceRange: '$$$',
        address: '555 Cherry Ln, Uptown',
        image: 'https://images.pexels.com/photos/248444/pexels-photo-248444.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Fresh Sushi', 'Quiet Atmosphere', 'Chef\'s Table', 'Premium Quality'],
        distance: '1.5 mi',
        estimatedTime: '22 min',
        aiScore: 94,
        matchReasons: ['Highest customer ratings', 'Premium ingredient quality', 'Intimate dining'],
        popularityTrend: 'up',
        aiInsights: 'Top-rated sushi with premium ingredients and intimate setting.'
      },
      {
        id: '6',
        name: 'Mama Mia Pizzeria',
        rating: 4.4,
        cuisine: 'Italian',
        priceRange: '$$',
        address: '777 Vine St, Little Italy',
        image: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Wood Fired Pizza', 'Family Style', 'Kids Friendly', 'Traditional'],
        distance: '1.0 mi',
        estimatedTime: '19 min',
        aiScore: 82,
        matchReasons: ['Authentic Italian cuisine', 'Great for families', 'Traditional methods'],
        popularityTrend: 'stable',
        aiInsights: 'Classic Italian with wood-fired pizzas and family atmosphere.'
      }
    ];

    // AI scoring based on preferences
    return baseRestaurants.map(restaurant => ({
      ...restaurant,
      aiScore: calculateAIScore(restaurant, preferences, contextMemory),
      matchReasons: generateMatchReasons(restaurant, preferences)
    })).sort((a, b) => (b.aiScore || 0) - (a.aiScore || 0));
  }, [contextMemory]);

  const calculateAIScore = (restaurant: Restaurant, preferences: UserPreferences, context: Record<string, any>): number => {
    let score = restaurant.rating * 10;
    
    // Preference matching
    if (restaurant.cuisine.toLowerCase() === preferences.foodType?.toLowerCase()) score += 20;
    if (restaurant.priceRange === preferences.budget) score += 15;
    if (preferences.kidsFriendly && restaurant.features.includes('Kids Menu')) score += 10;
    if (preferences.petFriendly && restaurant.features.includes('Pet Friendly')) score += 10;
    if (preferences.lgbtqFriendly && restaurant.features.includes('LGBTQ+ Friendly')) score += 10;
    
    // Context-based scoring
    if (context.lastInteraction && context.preferences) {
      if (context.preferences.foodType === restaurant.cuisine) score += 5;
    }
    
    return Math.min(100, score);
  };

  const generateMatchReasons = (restaurant: Restaurant, preferences: UserPreferences): string[] => {
    const reasons: string[] = [];
    
    if (restaurant.cuisine.toLowerCase() === preferences.foodType?.toLowerCase()) {
      reasons.push('Perfect cuisine match');
    }
    if (restaurant.priceRange === preferences.budget) {
      reasons.push('Within your budget');
    }
    if (preferences.occasion && restaurant.features.some(f => f.toLowerCase().includes(preferences.occasion.toLowerCase()))) {
      reasons.push(`Great for ${preferences.occasion}`);
    }
    if (restaurant.rating >= 4.5) {
      reasons.push('Highly rated by diners');
    }
    
    return reasons.slice(0, 3);
  };

  return {
    personality,
    isLearning,
    contextMemory,
    analyzeUserIntent,
    generateContextualResponse,
    learnFromInteraction,
    generateSmartRecommendations,
    conversationDepth: conversationDepth.current
  };
};

export default useAIAgent;