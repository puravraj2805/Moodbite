export interface UserPreferences {
  numberOfPeople: number;
  occasion: string;
  foodType: string;
  lgbtqFriendly: boolean;
  kidsFriendly: boolean;
  petFriendly: boolean;
  goodDrinks: boolean;
  ageLimit: string;
  musicPreference: string;
  priorityPreferences: string[];
  budget: string;
  location: string;
}

export interface Restaurant {
  id: string;
  name: string;
  rating: number;
  cuisine: string;
  priceRange: string;
  address: string;
  image: string;
  features: string[];
  distance: string;
  estimatedTime: string;
  googleReviews?: number;
  aiScore?: number;
  matchReasons?: string[];
  popularityTrend?: 'up' | 'down' | 'stable';
  aiInsights?: string;
}

export interface ChatMessage {
  id: string;
  type: 'user' | 'bot';
  message: string;
  timestamp: Date;
  isTyping?: boolean;
  attachments?: {
    type: 'restaurant' | 'preferences' | 'map';
    data: any;
  }[];
}

export interface AIPersonality {
  name: string;
  mood: 'excited' | 'professional' | 'casual' | 'enthusiastic';
  expertise: string[];
  conversationStyle: 'direct' | 'friendly' | 'detailed';
}

export interface UserSession {
  id: string;
  preferences?: UserPreferences;
  conversationHistory: ChatMessage[];
  learnedPreferences: Record<string, any>;
  visitCount: number;
  lastVisit?: Date;
}