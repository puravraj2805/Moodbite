import React from 'react';
import { useState } from 'react';
import { Restaurant } from '../types';
import { Star, MapPin, Clock, Navigation, Phone, X } from 'lucide-react';

interface RestaurantCardProps {
  restaurant: Restaurant;
  onGetDirections: (restaurant: Restaurant) => void;
}

const RestaurantCard: React.FC<RestaurantCardProps> = ({ restaurant, onGetDirections }) => {
  const [showPhoneModal, setShowPhoneModal] = useState(false);

  const handlePhoneClick = () => {
    setShowPhoneModal(true);
  };

  const handleCallNow = () => {
    if (restaurant.phoneNumber) {
      window.location.href = `tel:${restaurant.phoneNumber}`;
    }
  };

  return (
    <>
      <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
        <div className="relative h-48 overflow-hidden">
          <img
            src={restaurant.image}
            alt={restaurant.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute top-4 right-4 bg-white px-2 py-1 rounded-full flex items-center space-x-1 shadow-md">
            <Star className="w-4 h-4 text-yellow-500 fill-current" />
            <div className="text-xs text-gray-700">
              <div className="font-medium">{restaurant.rating}</div>
              <div className="text-gray-500">({restaurant.googleReviews || 0})</div>
            </div>
          </div>
          <div className="absolute top-4 left-4 bg-gradient-to-r from-orange-500 to-purple-600 text-white px-3 py-1 rounded-full text-sm font-medium">
            {restaurant.priceRange}
          </div>
        </div>

        <div className="p-6">
          <div className="flex justify-between items-start mb-3">
            <h3 className="text-xl font-bold text-gray-800 group-hover:text-orange-500 transition-colors">
              {restaurant.name}
            </h3>
            <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-sm font-medium">
              {restaurant.cuisine}
            </span>
          </div>

          <div className="flex items-center space-x-2 text-gray-600 mb-3">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">{restaurant.address}</span>
          </div>

          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
            <div className="flex items-center space-x-1">
              <Clock className="w-4 h-4" />
              <span>{restaurant.estimatedTime}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Navigation className="w-4 h-4" />
              <span>{restaurant.distance}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            {restaurant.features.map((feature, index) => (
              <span
                key={index}
                className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs font-medium"
              >
                {feature}
              </span>
            ))}
          </div>

          <div className="flex space-x-3">
            <button
              onClick={() => onGetDirections(restaurant)}
              className="flex-1 bg-gradient-to-r from-green-500 to-blue-500 text-white py-2 px-4 rounded-lg hover:from-green-600 hover:to-blue-600 transition-all duration-300 flex items-center justify-center space-x-2"
            >
              <Navigation className="w-4 h-4" />
              <span>Directions</span>
            </button>
            <button 
              onClick={handlePhoneClick}
              className="bg-orange-500 hover:bg-orange-600 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center"
            >
              <Phone className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Phone Modal */}
      {showPhoneModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-6 rounded-t-2xl">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">Call Restaurant</h2>
                <button
                  onClick={() => setShowPhoneModal(false)}
                  className="text-white hover:text-gray-200 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Phone className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">{restaurant.name}</h3>
                <div className="text-2xl font-bold text-gray-800 mb-2">
                  {restaurant.phoneNumber || "Phone not available"}
                </div>
                <p className="text-gray-600 text-sm">Tap the number to call directly</p>
              </div>

              <div className="space-y-3">
                {restaurant.phoneNumber && (
                  <button
                    onClick={handleCallNow}
                    className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-3 px-4 rounded-lg hover:from-green-600 hover:to-green-700 transition-all duration-300 flex items-center justify-center space-x-2 text-lg font-medium"
                  >
                    <Phone className="w-5 h-5" />
                    <span>Call Now</span>
                  </button>
                )}

                <button
                  onClick={() => setShowPhoneModal(false)}
                  className="w-full bg-gray-200 hover:bg-gray-300 text-gray-700 py-3 px-4 rounded-lg transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default RestaurantCard;