import React, { useEffect, useState } from 'react';
import { Brain, Sparkles, Zap } from 'lucide-react';

interface AITypingIndicatorProps {
  isVisible: boolean;
  message?: string;
}

const AITypingIndicator: React.FC<AITypingIndicatorProps> = ({ isVisible, message = "MoodBot is thinking..." }) => {
  const [dots, setDots] = useState('');
  const [currentIcon, setCurrentIcon] = useState(0);
  const icons = [Brain, Sparkles, Zap];

  useEffect(() => {
    if (!isVisible) return;

    const dotsInterval = setInterval(() => {
      setDots(prev => prev.length >= 3 ? '' : prev + '.');
    }, 500);

    const iconInterval = setInterval(() => {
      setCurrentIcon(prev => (prev + 1) % icons.length);
    }, 1200);

    return () => {
      clearInterval(dotsInterval);
      clearInterval(iconInterval);
    };
  }, [isVisible]);

  if (!isVisible) return null;

  const CurrentIcon = icons[currentIcon];

  return (
    <div className="flex justify-start mb-4">
      <div className="bg-gradient-to-r from-purple-100 to-blue-100 p-4 rounded-2xl max-w-xs">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center animate-pulse">
              <CurrentIcon className="w-4 h-4 text-white" />
            </div>
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-ping"></div>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center space-x-1">
              <span className="text-sm font-medium text-gray-700">{message}</span>
              <span className="text-purple-500 font-bold text-lg">{dots}</span>
            </div>
            <div className="flex space-x-1 mt-1">
              <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AITypingIndicator;