import React, { useState } from 'react';
import { UserPreferences } from '../types';
import { 
  Users, Calendar, Utensils, Heart, Baby, PawPrint, 
  Wine, Clock, Music, Star, DollarSign, MapPin, ArrowRight
} from 'lucide-react';

interface PreferencesFormProps {
  onSubmit: (preferences: UserPreferences) => void;
  onClose: () => void;
}

const PreferencesForm: React.FC<PreferencesFormProps> = ({ onSubmit, onClose }) => {
  const [preferences, setPreferences] = useState<UserPreferences>({
    numberOfPeople: 2,
    occasion: '',
    foodType: '',
    lgbtqFriendly: false,
    kidsFriendly: false,
    petFriendly: false,
    goodDrinks: false,
    ageLimit: '',
    musicPreference: '',
    priorityPreferences: [],
    budget: '',
    location: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(preferences);
  };

  const occasions = ['Date Night', 'Family Dinner', 'Business Meeting', 'Birthday', 'Anniversary', 'Casual Hangout'];
  const foodTypes = ['Italian', 'Chinese', 'Mexican', 'Indian', 'Japanese', 'American', 'Mediterranean', 'Thai'];
  const ageLimits = ['All Ages', '18+', '21+', 'Senior Friendly'];
  const musicPrefs = ['Live Music', 'Background Music', 'Quiet Atmosphere', 'DJ/Dance'];
  const budgetRanges = ['$ (Under $15)', '$$ ($15-30)', '$$$ ($30-60)', '$$$$ ($60+)'];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-orange-500 to-purple-600 text-white p-6 rounded-t-2xl">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Tell Us Your Preferences</h2>
            <button
              onClick={onClose}
              className="text-white hover:text-gray-200 transition-colors"
            >
              ✕
            </button>
          </div>
          <p className="text-orange-100 mt-2">Help us find the perfect restaurant for your mood</p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Number of People */}
            <div className="space-y-2">
              <label className="flex items-center space-x-2 text-gray-700 font-medium">
                <Users className="w-5 h-5 text-orange-500" />
                <span>Number of People</span>
              </label>
              <input
                type="number"
                min="1"
                max="20"
                value={preferences.numberOfPeople}
                onChange={(e) => setPreferences({...preferences, numberOfPeople: parseInt(e.target.value)})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>

            {/* Occasion */}
            <div className="space-y-2">
              <label className="flex items-center space-x-2 text-gray-700 font-medium">
                <Calendar className="w-5 h-5 text-purple-500" />
                <span>Occasion</span>
              </label>
              <select
                value={preferences.occasion}
                onChange={(e) => setPreferences({...preferences, occasion: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <option value="">Select an occasion</option>
                {occasions.map(occasion => (
                  <option key={occasion} value={occasion}>{occasion}</option>
                ))}
              </select>
            </div>

            {/* Food Type */}
            <div className="space-y-2">
              <label className="flex items-center space-x-2 text-gray-700 font-medium">
                <Utensils className="w-5 h-5 text-green-500" />
                <span>Type of Food</span>
              </label>
              <select
                value={preferences.foodType}
                onChange={(e) => setPreferences({...preferences, foodType: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="">Select cuisine type</option>
                {foodTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            {/* Age Limit */}
            <div className="space-y-2">
              <label className="flex items-center space-x-2 text-gray-700 font-medium">
                <Clock className="w-5 h-5 text-blue-500" />
                <span>Age Preference</span>
              </label>
              <select
                value={preferences.ageLimit}
                onChange={(e) => setPreferences({...preferences, ageLimit: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Select age preference</option>
                {ageLimits.map(limit => (
                  <option key={limit} value={limit}>{limit}</option>
                ))}
              </select>
            </div>

            {/* Music Preference */}
            <div className="space-y-2">
              <label className="flex items-center space-x-2 text-gray-700 font-medium">
                <Music className="w-5 h-5 text-pink-500" />
                <span>Music Preference</span>
              </label>
              <select
                value={preferences.musicPreference}
                onChange={(e) => setPreferences({...preferences, musicPreference: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
              >
                <option value="">Select music preference</option>
                {musicPrefs.map(pref => (
                  <option key={pref} value={pref}>{pref}</option>
                ))}
              </select>
            </div>

            {/* Budget */}
            <div className="space-y-2">
              <label className="flex items-center space-x-2 text-gray-700 font-medium">
                <DollarSign className="w-5 h-5 text-green-600" />
                <span>Budget Range</span>
              </label>
              <select
                value={preferences.budget}
                onChange={(e) => setPreferences({...preferences, budget: e.target.value})}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-600 focus:border-transparent"
              >
                <option value="">Select budget range</option>
                {budgetRanges.map(range => (
                  <option key={range} value={range}>{range}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Location */}
          <div className="space-y-2">
            <label className="flex items-center space-x-2 text-gray-700 font-medium">
              <MapPin className="w-5 h-5 text-red-500" />
              <span>Location</span>
            </label>
            <input
              type="text"
              placeholder="Enter your location or preferred area"
              value={preferences.location}
              onChange={(e) => setPreferences({...preferences, location: e.target.value})}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>

          {/* Boolean Preferences */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-800">Special Preferences</h3>
              
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.lgbtqFriendly}
                  onChange={(e) => setPreferences({...preferences, lgbtqFriendly: e.target.checked})}
                  className="w-5 h-5 text-rainbow-500 rounded focus:ring-2 focus:ring-purple-500"
                />
                <Heart className="w-5 h-5 text-purple-500" />
                <span className="text-gray-700">LGBTQ+ Friendly</span>
              </label>

              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.kidsFriendly}
                  onChange={(e) => setPreferences({...preferences, kidsFriendly: e.target.checked})}
                  className="w-5 h-5 text-blue-500 rounded focus:ring-2 focus:ring-blue-500"
                />
                <Baby className="w-5 h-5 text-blue-500" />
                <span className="text-gray-700">Kids Friendly</span>
              </label>

              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.petFriendly}
                  onChange={(e) => setPreferences({...preferences, petFriendly: e.target.checked})}
                  className="w-5 h-5 text-amber-500 rounded focus:ring-2 focus:ring-amber-500"
                />
                <PawPrint className="w-5 h-5 text-amber-500" />
                <span className="text-gray-700">Pet Friendly</span>
              </label>

              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.goodDrinks}
                  onChange={(e) => setPreferences({...preferences, goodDrinks: e.target.checked})}
                  className="w-5 h-5 text-indigo-500 rounded focus:ring-2 focus:ring-indigo-500"
                />
                <Wine className="w-5 h-5 text-indigo-500" />
                <span className="text-gray-700">Good Drinks Selection</span>
              </label>
            </div>

            {/* Priority Preference */}
            <div className="space-y-4">
              <h3 className="font-semibold text-gray-800">What matters most?</h3>
              <p className="text-sm text-gray-600">Select all that apply</p>
              <div className="space-y-3">
                <label className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    value="food"
                    checked={preferences.priorityPreferences.includes('food')}
                    onChange={(e) => {
                      const value = e.target.value;
                      const newPriorities = e.target.checked
                        ? [...preferences.priorityPreferences, value]
                        : preferences.priorityPreferences.filter(p => p !== value);
                      setPreferences({...preferences, priorityPreferences: newPriorities});
                    }}
                    className="w-5 h-5 text-orange-500"
                  />
                  <Utensils className="w-5 h-5 text-orange-500" />
                  <span className="text-gray-700">Great Food Quality</span>
                </label>

                <label className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    value="ambience"
                    checked={preferences.priorityPreferences.includes('ambience')}
                    onChange={(e) => {
                      const value = e.target.value;
                      const newPriorities = e.target.checked
                        ? [...preferences.priorityPreferences, value]
                        : preferences.priorityPreferences.filter(p => p !== value);
                      setPreferences({...preferences, priorityPreferences: newPriorities});
                    }}
                    className="w-5 h-5 text-purple-500"
                  />
                  <Star className="w-5 h-5 text-purple-500" />
                  <span className="text-gray-700">Great Ambience</span>
                </label>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-4 pt-6 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-3 bg-gradient-to-r from-orange-500 to-purple-600 text-white rounded-lg hover:from-orange-600 hover:to-purple-700 transition-all duration-300 flex items-center space-x-2"
            >
              <span>Find Restaurants</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PreferencesForm;