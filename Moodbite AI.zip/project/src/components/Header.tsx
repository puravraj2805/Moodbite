import React from 'react';
import { MessageCircle, MapPin, Heart, Home, Target, Info, Sparkles, Brain, ChefHat } from 'lucide-react';

interface HeaderProps {
  currentPage: 'home' | 'recommendations' | 'about';
  onNavigate: (page: 'home' | 'recommendations' | 'about') => void;
  onChatToggle: () => void;
  isChatOpen: boolean;
}

const Header: React.FC<HeaderProps> = ({ currentPage, onNavigate, onChatToggle, isChatOpen }) => {
  const navigationItems = [
    {
      id: 'home',
      label: 'Home',
      icon: Home,
      description: 'Discover MoodBites',
      color: 'from-orange-400 to-red-500'
    },
    {
      id: 'recommendations',
      label: 'AI Recommendations',
      icon: Target,
      description: 'Smart food matches',
      color: 'from-purple-400 to-indigo-500'
    },
    {
      id: 'about',
      label: 'About',
      icon: Info,
      description: 'Learn more',
      color: 'from-green-400 to-emerald-500'
    }
  ];

  return (
    <header className="bg-white shadow-lg border-b border-gray-100 sticky top-0 z-50 backdrop-blur-md bg-opacity-95">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo Section */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="relative">
              <div className="bg-gradient-to-r from-orange-500 to-purple-600 p-3 rounded-2xl shadow-lg">
                <ChefHat className="w-8 h-8 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full animate-pulse shadow-md"></div>
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-500 to-purple-600 bg-clip-text text-transparent">
                MoodBites
              </h1>
              <div className="flex items-center space-x-1 text-xs text-gray-500">
                <Brain className="w-3 h-3" />
                <span>AI Food Agent</span>
              </div>
            </div>
          </div>
          
          {/* Modern Navigation Cards */}
          <nav className="hidden lg:flex items-center space-x-4">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <button 
                  key={item.id}
                  onClick={() => onNavigate(item.id as 'home' | 'recommendations' | 'about')}
                  className={`relative group px-6 py-3 rounded-2xl transition-all duration-300 ${
                    isActive 
                      ? 'bg-gradient-to-r ' + item.color + ' text-white shadow-lg transform scale-105' 
                      : 'bg-gray-50 hover:bg-gray-100 text-gray-700 hover:shadow-md hover:scale-102'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-gray-600 group-hover:text-gray-800'}`} />
                    <div className="text-left">
                      <div className={`font-semibold text-sm ${isActive ? 'text-white' : 'text-gray-800'}`}>
                        {item.label}
                      </div>
                      <div className={`text-xs ${isActive ? 'text-white/80' : 'text-gray-500'}`}>
                        {item.description}
                      </div>
                    </div>
                  </div>
                  
                  {/* Active indicator */}
                  {isActive && (
                    <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-white rounded-full shadow-md"></div>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Mobile Navigation */}
          <nav className="lg:hidden flex items-center space-x-2">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <button 
                  key={item.id}
                  onClick={() => onNavigate(item.id as 'home' | 'recommendations' | 'about')}
                  className={`relative p-3 rounded-xl transition-all duration-300 ${
                    isActive 
                      ? 'bg-gradient-to-r ' + item.color + ' text-white shadow-lg' 
                      : 'bg-gray-50 hover:bg-gray-100 text-gray-600'
                  }`}
                  title={item.label}
                >
                  <Icon className="w-5 h-5" />
                  {isActive && (
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full shadow-sm"></div>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center space-x-3">
            {/* Chat Button */}
            <button
              onClick={onChatToggle}
              className={`relative flex items-center space-x-2 px-6 py-3 rounded-xl transition-all duration-300 transform hover:scale-105 ${
                isChatOpen
                  ? 'bg-gradient-to-r from-orange-500 to-purple-600 text-white shadow-lg'
                  : 'bg-gradient-to-r from-gray-100 to-gray-50 text-gray-700 hover:from-orange-50 hover:to-purple-50 hover:shadow-md'
              }`}
            >
              <MessageCircle className={`w-5 h-5 ${isChatOpen ? 'animate-pulse' : ''}`} />
              <div className="hidden sm:block text-left">
                <div className="font-semibold text-sm">AI Chat</div>
                <div className={`text-xs ${isChatOpen ? 'text-white/80' : 'text-gray-500'}`}>
                  {isChatOpen ? 'Active' : 'Get Help'}
                </div>
              </div>
              
              {/* Chat indicator */}
              {isChatOpen && (
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full animate-pulse shadow-md">
                  <div className="absolute inset-1 bg-white rounded-full"></div>
                </div>
              )}
              
              {/* Sparkles animation */}
              <Sparkles className={`w-4 h-4 absolute -top-2 -right-2 text-yellow-400 ${isChatOpen ? 'animate-spin' : 'hidden'}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Gradient border */}
      <div className="h-1 bg-gradient-to-r from-orange-400 via-purple-500 to-green-400"></div>
    </header>
  );
};

export default Header;