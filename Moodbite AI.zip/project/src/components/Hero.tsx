import React from 'react';
import { ChefHat, Users, MapPin, Sparkles } from 'lucide-react';

interface HeroProps {
  onStartClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onStartClick }) => {
  return (
    <section id="home" className="bg-gradient-to-br from-orange-50 via-purple-50 to-green-50 py-20">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-4xl mx-auto">
          <div className="flex justify-center mb-6">
            <div className="bg-gradient-to-r from-orange-400 to-purple-500 p-4 rounded-full animate-pulse">
              <ChefHat className="w-12 h-12 text-white" />
            </div>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-gray-800 mb-6">
            Find Your Perfect
            <span className="block bg-gradient-to-r from-orange-500 via-purple-600 to-green-500 bg-clip-text text-transparent">
              Food Experience
            </span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
            MoodBites uses AI to understand your preferences and mood to recommend the perfect restaurant 
            for any occasion. From intimate dinners to family gatherings, we've got you covered.
          </p>

          <div className="flex flex-wrap justify-center gap-6 mb-10">
            <div className="flex items-center space-x-2 bg-white rounded-full px-4 py-2 shadow-md">
              <Users className="w-5 h-5 text-orange-500" />
              <span className="text-sm font-medium text-gray-700">Group Friendly</span>
            </div>
            <div className="flex items-center space-x-2 bg-white rounded-full px-4 py-2 shadow-md">
              <MapPin className="w-5 h-5 text-green-500" />
              <span className="text-sm font-medium text-gray-700">Location Based</span>
            </div>
            <div className="flex items-center space-x-2 bg-white rounded-full px-4 py-2 shadow-md">
              <Sparkles className="w-5 h-5 text-purple-500" />
              <span className="text-sm font-medium text-gray-700">AI Powered</span>
            </div>
          </div>

          <button
            onClick={onStartClick}
            className="bg-gradient-to-r from-orange-500 to-purple-600 hover:from-orange-600 hover:to-purple-700 text-white px-8 py-4 rounded-full text-lg font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
          >
            Start Finding Restaurants
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;