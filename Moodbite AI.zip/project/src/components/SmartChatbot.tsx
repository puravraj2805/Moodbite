import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, UserPreferences, Restaurant } from '../types';
import { Send, Bot, User, Brain, Sparkles, TrendingUp, MapPin } from 'lucide-react';
import VoiceAssistant from './VoiceAssistant';
import AITypingIndicator from './AITypingIndicator';
import RestaurantCard from './RestaurantCard';
import useAIAgent from '../hooks/useAIAgent';

interface SmartChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  userPreferences?: UserPreferences;
  onPreferencesUpdate?: (preferences: Partial<UserPreferences>) => void;
  onGetDirections?: (restaurant: Restaurant) => void;
}

const SmartChatbot: React.FC<SmartChatbotProps> = ({ 
  isOpen, 
  onClose, 
  userPreferences,
  onPreferencesUpdate,
  onGetDirections 
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'bot',
      message: '👋 **Hey there, food lover!** I\'m MoodBot, your personal food buddy here to help you decide "Where am I eating tonight?" 🍽️\n\n✨ **I specialize in recommending specific dishes based on:**\n• Your **mood** (light, solid, heavy)\n• Your **cuisine** preference (Indian, Mexican, Italian, Asian, Mediterranean, American)\n• The **occasion** (casual, business, friends catch-up, festival)\n\n🎯 **Just tell me something like:**\n• "I want something light and Italian"\n• "Heavy mood, Indian cuisine"\n• "What should I eat for a business dinner?"\n\nWhat\'s your food vibe today? 😋',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showInsights, setShowInsights] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Food recommendation data
  const foodRecommendations = {
    light: {
      indian: ['samosa', 'pakoda', 'puff', 'pani puri', 'masala peanuts', 'bhel puri'],
      mexican: ['nachos', 'cheese sticks', 'elote (Mexican street corn)', 'quesadilla slices'],
      italian: ['bruschetta', 'garlic bread', 'caprese salad', 'antipasto bites'],
      asian: ['sushi rolls', 'spring rolls', 'edamame', 'miso soup'],
      mediterranean: ['hummus with pita', 'falafel balls', 'olives', 'tzatziki with veggies'],
      american: ['cookies', 'donuts', 'iced tea', 'French fries', 'popcorn', 'sliders']
    },
    solid: {
      indian: ['pulao', 'biryani (small plate)', 'naan with paneer curry', 'chole bhature', 'dosa'],
      mexican: ['burrito bowl', 'enchiladas (half portion)', 'tacos', 'quesadilla'],
      italian: ['pasta (penne arrabiata, Alfredo)', 'risotto', 'medium pizza', 'ravioli'],
      asian: ['ramen', 'teriyaki bowl', 'bibimbap (Korean rice bowl)', 'pad thai'],
      mediterranean: ['shawarma wrap', 'gyros', 'falafel wrap', 'couscous salad'],
      american: ['burgers', 'sandwiches', 'wraps', 'mac & cheese', 'Caesar salad']
    },
    heavy: {
      indian: ['thali', 'butter chicken with naan + rice', 'tandoori platter', 'malai kofta + gulab jamun'],
      mexican: ['fajita platter', 'loaded burrito', 'chimichangas', 'carnitas with rice and beans + churros'],
      italian: ['lasagna', 'large pizza', 'gnocchi with sauce', 'osso buco + tiramisu'],
      asian: ['hot pot', 'Peking duck', 'dim sum spread', 'Thai green curry with rice + mango sticky rice'],
      mediterranean: ['mixed grill platter (lamb, chicken, kebabs)', 'moussaka', 'spanakopita + baklava'],
      american: ['steak dinner with mashed potatoes', 'BBQ ribs', 'surf & turf', 'fried chicken bucket + cheesecake']
    }
  };

  const {
    personality,
    isLearning,
    contextMemory,
    analyzeUserIntent,
    generateContextualResponse,
    learnFromInteraction,
    generateSmartRecommendations,
    conversationDepth
  } = useAIAgent();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const generateIntelligentResponse = async (userMessage: string): Promise<{ response: string; restaurants: Restaurant[] }> => {
    const message = userMessage.toLowerCase();
    
    // Learn from user interaction
    learnFromInteraction(userMessage, userPreferences);
    
    let response = '';
    let restaurants: Restaurant[] = [];

    // Check for mood-based food recommendations
    if (message.includes('recommend') || message.includes('suggest') || message.includes('food') || 
        message.includes('eat') || message.includes('hungry') || message.includes('dish')) {
      
      // Extract mood
      let mood = 'solid'; // default
      if (message.includes('light') || message.includes('snack') || message.includes('small')) mood = 'light';
      else if (message.includes('heavy') || message.includes('full') || message.includes('feast') || message.includes('big')) mood = 'heavy';
      
      // Extract cuisine
      let cuisine = 'american'; // default
      if (message.includes('indian')) cuisine = 'indian';
      else if (message.includes('mexican')) cuisine = 'mexican';
      else if (message.includes('italian')) cuisine = 'italian';
      else if (message.includes('asian') || message.includes('chinese') || message.includes('japanese')) cuisine = 'asian';
      else if (message.includes('mediterranean')) cuisine = 'mediterranean';
      
      // Get food recommendations
      const moodRecommendations = foodRecommendations[mood as keyof typeof foodRecommendations];
      const dishOptions = moodRecommendations[cuisine as keyof typeof moodRecommendations];
      const selectedDishes = dishOptions.slice(0, 3); // Get first 3 dishes
      
      response = `🍽️ **Perfect! Based on your ${mood} mood and ${cuisine} cuisine preference, here are my recommendations:**\n\n`;
      response += `🎯 **Mood:** ${mood.charAt(0).toUpperCase() + mood.slice(1)}\n`;
      response += `🌮 **Cuisine:** ${cuisine.charAt(0).toUpperCase() + cuisine.slice(1)}\n\n`;
      response += `✨ **My top picks for you:**\n`;
      selectedDishes.forEach((dish, index) => {
        response += `${index + 1}. **${dish}**\n`;
      });
      
      response += `\n💡 **Pro tip:** These dishes are perfect for your current vibe! Want more options or a different cuisine? Just ask! 😊`;
      
    } else if (message.includes('mood') || message.includes('how are you feeling') || message.includes('what mood')) {
      response = `🤔 **Great question! Let me help you figure out what you're craving:**\n\n`;
      response += `🥗 **Light mood:** Perfect for snacks, catch-ups, or when you're not super hungry\n`;
      response += `🍝 **Solid mood:** A proper meal but not too heavy - perfect for dinner\n`;
      response += `🍖 **Heavy mood:** When you want a full feast with starters, mains, and desserts!\n\n`;
      response += `Just tell me: "I'm feeling light and want Italian food" or "Heavy mood, Mexican cuisine please!" 😋`;
      
    } else if (message.includes('cuisine') || message.includes('type of food')) {
      response = `🌍 **I've got amazing recommendations for these cuisines:**\n\n`;
      response += `🇮🇳 **Indian:** From samosas to biryanis to full thalis\n`;
      response += `🇲🇽 **Mexican:** Tacos, burritos, nachos, and more\n`;
      response += `🇮🇹 **Italian:** Pasta, pizza, risotto, you name it!\n`;
      response += `🥡 **Asian:** Sushi, ramen, pad thai, dim sum\n`;
      response += `🥙 **Mediterranean:** Hummus, shawarma, gyros, baklava\n`;
      response += `🍔 **American:** Burgers, BBQ, steaks, classic comfort food\n\n`;
      response += `What cuisine matches your mood today? 🤤`;
      
    } else if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
      response = `👋 **Hey there, food lover!** I'm your personal food buddy here to help you decide "Where am I eating tonight?" 🍽️\n\n`;
      response += `Just tell me:\n`;
      response += `• Your **mood** (light, solid, or heavy)\n`;
      response += `• Your **cuisine** preference (Indian, Mexican, Italian, Asian, Mediterranean, American)\n`;
      response += `• Or just say something like: "I want something light and Italian" 🍝\n\n`;
      response += `Let's find your perfect meal! What's your vibe today? ✨`;
      
    } else {
      response = `🤖 **I'm here to help you decide what to eat!** 🍽️\n\n`;
      response += `Try asking me something like:\n`;
      response += `• "I'm feeling heavy mood with Indian food"\n`;
      response += `• "Light snacks, Italian cuisine"\n`;
      response += `• "What should I eat for dinner?"\n`;
      response += `• "Mexican food recommendations"\n\n`;
      response += `What's your food mood today? 😋`;
    }

    // Add contextual memory references
    if (contextMemory.messageCount > 3) {
      response += `\n\n💭 Based on our conversation, I'm getting a better sense of your taste preferences!`;
    }

    if (Math.random() > 0.8) {
      const funEmojis = ['🤤', '😋', '🍽️', '✨', '🎉'];
      response += `\n\nHappy eating! ${funEmojis[Math.floor(Math.random() * funEmojis.length)]}`;
    }

    return { response, restaurants };
  };

  const handleVoiceInput = async (voiceText: string) => {
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      message: voiceText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    try {
      const { response: botResponse, restaurants } = await generateIntelligentResponse(voiceText);
      
      setTimeout(() => {
        const botMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          type: 'bot',
          message: botResponse,
          timestamp: new Date(),
          attachments: restaurants.length > 0 ? [{
            type: 'restaurant',
            data: restaurants.slice(0, 3) // Show top 3 restaurants
          }] : undefined
        };
        
        setMessages(prev => [...prev, botMessage]);
        setIsTyping(false);
      }, 1500 + Math.random() * 1000); // More realistic thinking time
    } catch (error) {
      setIsTyping(false);
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      message: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const messageToProcess = inputMessage;
    setInputMessage('');
    setIsTyping(true);

    try {
      const { response: botResponse, restaurants } = await generateIntelligentResponse(messageToProcess);
      
      setTimeout(() => {
        const botMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          type: 'bot',
          message: botResponse,
          timestamp: new Date(),
          attachments: restaurants.length > 0 ? [{
            type: 'restaurant',
            data: restaurants.slice(0, 3) // Show top 3 restaurants
          }] : undefined
        };
        
        setMessages(prev => [...prev, botMessage]);
        setIsTyping(false);
      }, 1500 + Math.random() * 1000);
    } catch (error) {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getLastBotMessage = () => {
    const lastBotMsg = messages.slice().reverse().find(msg => msg.type === 'bot');
    return lastBotMsg?.message;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-4 right-4 w-96 h-[700px] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col z-50 overflow-hidden">
      {/* Enhanced Header */}
      <div className="bg-gradient-to-r from-purple-600 via-blue-500 to-indigo-600 text-white p-4 rounded-t-2xl">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-10 h-10 bg-white bg-opacity-20 rounded-full flex items-center justify-center backdrop-blur-sm">
                <Brain className="w-5 h-5" />
              </div>
              {isLearning && (
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full animate-ping"></div>
              )}
            </div>
            <div>
              <h3 className="font-bold text-lg">{personality.name} AI</h3>
              <div className="flex items-center space-x-2 text-sm text-purple-100">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span>Learning your taste</span>
                {conversationDepth > 0 && (
                  <span className="bg-white bg-opacity-20 px-2 py-0.5 rounded-full text-xs">
                    {conversationDepth} exchanges
                  </span>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowInsights(!showInsights)}
              className="text-white hover:text-purple-200 transition-colors"
              title="AI Insights"
            >
              <Sparkles className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="text-white hover:text-purple-200 transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        {/* AI Insights Panel */}
        {showInsights && (
          <div className="mt-3 bg-white bg-opacity-10 rounded-lg p-3 backdrop-blur-sm">
            <div className="text-xs space-y-2">
              <div className="flex items-center space-x-2">
                <TrendingUp className="w-3 h-3" />
                <span>Conversation depth: Level {conversationDepth}</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="w-3 h-3" />
                <span>Memory items: {Object.keys(contextMemory).length}</span>
              </div>
              {userPreferences && (
                <div className="flex items-center space-x-2">
                  <User className="w-3 h-3" />
                  <span>Preferences learned: {Object.keys(userPreferences).filter(k => userPreferences[k as keyof UserPreferences]).length}</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-gray-50 to-white">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className="max-w-[95%] flex flex-col">
              <div
                className={`p-4 rounded-2xl ${
                  message.type === 'user'
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white self-end'
                    : 'bg-white text-gray-800 shadow-md border border-gray-100 self-start'
                }`}
              >
                <div className="flex items-start space-x-2">
                  {message.type === 'bot' && (
                    <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center mt-0.5">
                      <Bot className="w-3 h-3 text-white" />
                    </div>
                  )}
                  <div className="flex-1">
                    <p className="text-sm leading-relaxed whitespace-pre-line">{message.message}</p>
                    <p className={`text-xs mt-2 ${
                      message.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                    }`}>
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  {message.type === 'user' && (
                    <User className="w-4 h-4 mt-0.5 text-white opacity-75" />
                  )}
                </div>
              </div>
              
              {/* Restaurant Attachments */}
              {message.attachments && message.attachments[0]?.type === 'restaurant' && (
                <div className="mt-3 space-y-2">
                  {message.attachments[0].data.map((restaurant: Restaurant) => (
                    <div 
                      key={restaurant.id} 
                      className="bg-gradient-to-r from-orange-50 to-purple-50 rounded-xl border border-orange-200 overflow-hidden transform hover:scale-105 transition-all duration-300"
                    >
                      <div className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h4 className="font-bold text-gray-800">{restaurant.name}</h4>
                              <span className="bg-gradient-to-r from-orange-500 to-purple-600 text-white px-2 py-1 rounded-full text-xs font-medium">
                                {restaurant.aiScore}% Match
                              </span>
                            </div>
                            <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                              <span className="flex items-center space-x-1">
                                ⭐ <span>{restaurant.rating}</span>
                              </span>
                              <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">
                                {restaurant.cuisine}
                              </span>
                              <span className="text-purple-600 font-medium">{restaurant.priceRange}</span>
                            </div>
                            <p className="text-xs text-gray-500 mb-2">📍 {restaurant.address}</p>
                            <p className="text-xs text-blue-600 italic">{restaurant.aiInsights}</p>
                          </div>
                          <img 
                            src={restaurant.image} 
                            alt={restaurant.name}
                            className="w-20 h-16 object-cover rounded-lg ml-3"
                          />
                        </div>
                        <div className="flex items-center justify-between mt-3">
                          <div className="flex flex-wrap gap-1">
                            {restaurant.features.slice(0, 3).map((feature, idx) => (
                              <span key={idx} className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs">
                                {feature}
                              </span>
                            ))}
                          </div>
                          <button
                            onClick={() => onGetDirections && onGetDirections(restaurant)}
                            className="bg-gradient-to-r from-green-500 to-blue-500 text-white px-3 py-1 rounded-lg text-xs hover:from-green-600 hover:to-blue-600 transition-all duration-300"
                          >
                            Get Directions
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        
        <AITypingIndicator 
          isVisible={isTyping} 
          message={isLearning ? "Learning from your preferences..." : "Analyzing the perfect recommendations..."}
        />
        
        <div ref={messagesEndRef} />
      </div>

      {/* Voice Assistant */}
      <div className="px-4 pb-2 bg-gradient-to-t from-gray-50 to-transparent">
        <VoiceAssistant 
          onVoiceInput={handleVoiceInput}
          lastBotMessage={getLastBotMessage()}
        />
      </div>

      {/* Enhanced Input */}
      <div className="p-4 border-t border-gray-200 bg-white">
        <div className="flex space-x-3">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={`Ask ${personality.name} anything about food...`}
            className="flex-1 p-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300"
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || isTyping}
            className="bg-gradient-to-r from-purple-500 to-blue-500 text-white p-3 rounded-xl hover:from-purple-600 hover:to-blue-600 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 active:scale-95"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default SmartChatbot;
