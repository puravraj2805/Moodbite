import React from 'react';
import { Restaurant } from '../types';
import { Navigation, Clock, MapPin, X, ExternalLink } from 'lucide-react';

interface DirectionsModalProps {
  restaurant: Restaurant | null;
  isOpen: boolean;
  onClose: () => void;
}

const DirectionsModal: React.FC<DirectionsModalProps> = ({ restaurant, isOpen, onClose }) => {
  if (!isOpen || !restaurant) return null;

  const openInGoogleMaps = () => {
    const encodedAddress = encodeURIComponent(restaurant.address);
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}`, '_blank');
  };

  const openInAppleMaps = () => {
    const encodedAddress = encodeURIComponent(restaurant.address);
    window.open(`http://maps.apple.com/?daddr=${encodedAddress}`, '_blank');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="bg-gradient-to-r from-green-500 to-blue-500 text-white p-6 rounded-t-2xl">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Get Directions</h2>
            <button
              onClick={onClose}
              className="text-white hover:text-gray-200 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Navigation className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">{restaurant.name}</h3>
            <div className="flex items-center justify-center space-x-2 text-gray-600 mb-4">
              <MapPin className="w-4 h-4" />
              <span>{restaurant.address}</span>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Navigation className="w-5 h-5 text-green-500" />
                <span className="font-medium text-gray-700">Distance</span>
              </div>
              <span className="text-gray-800 font-semibold">{restaurant.distance}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5 text-blue-500" />
                <span className="font-medium text-gray-700">Estimated Time</span>
              </div>
              <span className="text-gray-800 font-semibold">{restaurant.estimatedTime}</span>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-gray-800">Open with:</h4>
            
            <button
              onClick={openInGoogleMaps}
              className="w-full flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">G</span>
                </div>
                <span className="font-medium text-gray-700">Google Maps</span>
              </div>
              <ExternalLink className="w-5 h-5 text-gray-400" />
            </button>

            <button
              onClick={openInAppleMaps}
              className="w-full flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">🍎</span>
                </div>
                <span className="font-medium text-gray-700">Apple Maps</span>
              </div>
              <ExternalLink className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          <div className="pt-4 border-t">
            <button
              onClick={onClose}
              className="w-full bg-gray-200 hover:bg-gray-300 text-gray-700 py-3 px-4 rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DirectionsModal;