import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { Send, Bot, User } from 'lucide-react';
import VoiceAssistant from './VoiceAssistant';

interface ChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

const Chatbot: React.FC<ChatbotProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'bot',
      message: 'Hi! I\'m MoodBot, your personal dining assistant. How can I help you find the perfect restaurant today?',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateBotResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('recommend') || message.includes('suggest')) {
      return 'I\'d love to help you find the perfect restaurant! To give you the best recommendations, could you tell me about your preferences? For example, what type of cuisine are you in the mood for, how many people will be dining, and what\'s your budget?';
    }
    
    if (message.includes('budget') || message.includes('price') || message.includes('cost')) {
      return 'Great question about budget! I can help you find restaurants in different price ranges: $ for under $15, $$ for $15-30, $$$ for $30-60, and $$$$ for $60+. What range works best for you?';
    }
    
    if (message.includes('location') || message.includes('where') || message.includes('near')) {
      return 'I can help you find restaurants in your area! Just share your location or the area you\'d prefer, and I\'ll show you the best options nearby with directions and estimated travel time.';
    }
    
    if (message.includes('cuisine') || message.includes('food type')) {
      return 'I love talking about food! I can help you find restaurants serving Italian, Chinese, Mexican, Indian, Japanese, American, Mediterranean, Thai, and many other cuisines. What are you craving?';
    }
    
    if (message.includes('kids') || message.includes('family')) {
      return 'Planning a family meal? I can find kid-friendly restaurants with children\'s menus, high chairs, and a welcoming atmosphere for families. Many also have play areas or entertainment for little ones!';
    }
    
    if (message.includes('date') || message.includes('romantic')) {
      return 'Looking for a romantic spot? I can recommend restaurants with intimate ambiance, candlelit tables, quiet atmosphere, and excellent wine selections perfect for a special date night!';
    }
    
    if (message.includes('thank')) {
      return 'You\'re very welcome! I\'m here whenever you need help finding the perfect dining spot. Enjoy your meal! 🍽️';
    }
    
    return 'I understand you\'re looking for dining recommendations. I can help you find restaurants based on your preferences like cuisine type, budget, location, occasion, and special needs. Feel free to ask me about any specific requirements you have!';
  };

  const handleVoiceInput = (voiceText: string) => {
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      message: voiceText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    // Simulate bot thinking time
    setTimeout(() => {
      const botResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        message: generateBotResponse(voiceText),
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      message: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate bot thinking time
    setTimeout(() => {
      const botResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        message: generateBotResponse(inputMessage),
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getLastBotMessage = () => {
    const lastBotMsg = messages.slice().reverse().find(msg => msg.type === 'bot');
    return lastBotMsg?.message;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-4 right-4 w-96 h-[650px] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col z-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-purple-600 text-white p-4 rounded-t-2xl">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold">MoodBot</h3>
              <p className="text-sm text-orange-100">Online now</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:text-gray-200 transition-colors"
          >
            ✕
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] p-3 rounded-2xl ${
                message.type === 'user'
                  ? 'bg-gradient-to-r from-orange-500 to-purple-600 text-white'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              <div className="flex items-start space-x-2">
                {message.type === 'bot' && (
                  <Bot className="w-4 h-4 mt-0.5 text-orange-500" />
                )}
                <p className="text-sm leading-relaxed">{message.message}</p>
                {message.type === 'user' && (
                  <User className="w-4 h-4 mt-0.5 text-white opacity-75" />
                )}
              </div>
              <p className={`text-xs mt-1 ${
                message.type === 'user' ? 'text-orange-100' : 'text-gray-500'
              }`}>
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-100 text-gray-800 p-3 rounded-2xl">
              <div className="flex items-center space-x-2">
                <Bot className="w-4 h-4 text-orange-500" />
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Voice Assistant */}
      <div className="px-4 pb-2">
        <VoiceAssistant 
          onVoiceInput={handleVoiceInput}
          lastBotMessage={getLastBotMessage()}
        />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex space-x-2">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Ask me about restaurants..."
            className="flex-1 p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || isTyping}
            className="bg-gradient-to-r from-orange-500 to-purple-600 text-white p-2 rounded-lg hover:from-orange-600 hover:to-purple-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;