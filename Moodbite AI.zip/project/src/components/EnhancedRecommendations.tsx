import React, { useState } from 'react';
import { Restaurant, UserPreferences } from '../types';
import RestaurantCard from './RestaurantCard';
import { Filter, SortAsc, MapPin, Star, TrendingUp, Users } from 'lucide-react';

interface EnhancedRecommendationsProps {
  preferences: UserPreferences;
  onGetDirections: (restaurant: Restaurant) => void;
}

const EnhancedRecommendations: React.FC<EnhancedRecommendationsProps> = ({ 
  preferences, 
  onGetDirections 
}) => {
  const [filterCount, setFilterCount] = useState<'all' | 'top2' | 'top10'>('all');
  const [sortBy, setSortBy] = useState<'rating' | 'distance' | 'price' | 'popularity'>('rating');
  const [showSources, setShowSources] = useState(false);

  // Enhanced mock restaurant data with source information
  const mockRestaurants: Restaurant[] = [
    {
      id: '1',
      name: 'The Garden Bistro',
      rating: 4.8,
      cuisine: preferences.foodType || 'Mediterranean',
      priceRange: preferences.budget || '$$',
      address: '123 Main St, Downtown',
      image: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['Outdoor Seating', 'Live Music', 'LGBTQ+ Friendly', 'Pet Friendly'],
      distance: '0.5 mi',
      estimatedTime: '15 min'
    },
    {
      id: '2',
      name: 'Spice Route',
      rating: 4.6,
      cuisine: 'Indian',
      priceRange: '$$$',
      address: '456 Oak Ave, Midtown',
      image: 'https://images.pexels.com/photos/1579739/pexels-photo-1579739.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['Kids Menu', 'Good Drinks', 'Date Night', 'Highly Rated on Google'],
      distance: '1.2 mi',
      estimatedTime: '20 min'
    },
    {
      id: '3',
      name: 'Coastal Catch',
      rating: 4.7,
      cuisine: 'Seafood',
      priceRange: '$$$$',
      address: '789 Beach Rd, Waterfront',
      image: 'https://images.pexels.com/photos/696218/pexels-photo-696218.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['Ocean View', 'Fresh Seafood', 'Romantic', 'Pinterest Featured'],
      distance: '2.1 mi',
      estimatedTime: '25 min'
    },
    {
      id: '4',
      name: 'Urban Eats',
      rating: 4.5,
      cuisine: 'American',
      priceRange: '$$',
      address: '321 City Plaza, Central',
      image: 'https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['Family Friendly', 'Quick Service', 'All Ages', 'Reddit Favorite'],
      distance: '0.8 mi',
      estimatedTime: '18 min'
    },
    {
      id: '5',
      name: 'Sakura Sushi',
      rating: 4.9,
      cuisine: 'Japanese',
      priceRange: '$$$',
      address: '555 Cherry Ln, Uptown',
      image: 'https://images.pexels.com/photos/248444/pexels-photo-248444.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['Fresh Sushi', 'Quiet Atmosphere', 'Date Night', 'Google Top Pick'],
      distance: '1.5 mi',
      estimatedTime: '22 min'
    },
    {
      id: '6',
      name: 'Mama Mia Pizzeria',
      rating: 4.4,
      cuisine: 'Italian',
      priceRange: '$$',
      address: '777 Vine St, Little Italy',
      image: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['Wood Fired Pizza', 'Family Style', 'Kids Friendly', 'Trending on Social'],
      distance: '1.0 mi',
      estimatedTime: '19 min'
    }
  ];

  const getFilteredRestaurants = () => {
    let filtered = [...mockRestaurants];

    // Sort restaurants
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'rating':
          return b.rating - a.rating;
        case 'distance':
          return parseFloat(a.distance) - parseFloat(b.distance);
        case 'price':
          return a.priceRange.length - b.priceRange.length;
        case 'popularity':
          // Mock popularity based on features
          const getPopularityScore = (restaurant: Restaurant) => {
            let score = restaurant.rating * 10;
            if (restaurant.features.some(f => f.includes('Google') || f.includes('Pinterest') || f.includes('Reddit'))) {
              score += 5;
            }
            return score;
          };
          return getPopularityScore(b) - getPopularityScore(a);
        default:
          return 0;
      }
    });

    // Apply filter count
    if (filterCount === 'top2') {
      filtered = filtered.slice(0, 2);
    } else if (filterCount === 'top10') {
      filtered = filtered.slice(0, Math.min(10, filtered.length));
    }

    return filtered;
  };

  const filteredRestaurants = getFilteredRestaurants();

  const getSourcesData = () => {
    return {
      google: filteredRestaurants.filter(r => r.features.some(f => f.includes('Google'))).length,
      pinterest: filteredRestaurants.filter(r => r.features.some(f => f.includes('Pinterest'))).length,
      reddit: filteredRestaurants.filter(r => r.features.some(f => f.includes('Reddit'))).length,
      social: filteredRestaurants.filter(r => r.features.some(f => f.includes('Social'))).length,
    };
  };

  return (
    <section id="recommendations" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Perfect Matches for You
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Based on your preferences for {preferences.occasion || 'dining'} with {preferences.numberOfPeople} people
          </p>
          
          {/* Sources Information */}
          <div className="mt-6 flex justify-center">
            <button
              onClick={() => setShowSources(!showSources)}
              className="bg-white rounded-full px-6 py-2 shadow-md hover:shadow-lg transition-all duration-300 flex items-center space-x-2"
            >
              <TrendingUp className="w-5 h-5 text-blue-500" />
              <span className="text-sm font-medium text-gray-700">View Data Sources</span>
            </button>
          </div>

          {showSources && (
            <div className="mt-4 bg-white rounded-lg p-4 shadow-md max-w-md mx-auto">
              <h4 className="font-semibold text-gray-800 mb-3">Recommendations sourced from:</h4>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span>Google Reviews ({getSourcesData().google})</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-pink-500 rounded-full"></div>
                  <span>Pinterest ({getSourcesData().pinterest})</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                  <span>Reddit ({getSourcesData().reddit})</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <span>Social Media ({getSourcesData().social})</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Enhanced Filters and Controls */}
        <div className="flex flex-wrap justify-between items-center mb-8 bg-white p-4 rounded-lg shadow-md">
          <div className="flex items-center space-x-4 mb-4 sm:mb-0">
            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-gray-600" />
              <span className="font-medium text-gray-700">Show:</span>
            </div>
            <select
              value={filterCount}
              onChange={(e) => setFilterCount(e.target.value as 'all' | 'top2' | 'top10')}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              <option value="all">All Results</option>
              <option value="top2">Top 2</option>
              <option value="top10">Top 10</option>
            </select>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <SortAsc className="w-5 h-5 text-gray-600" />
              <span className="font-medium text-gray-700">Sort by:</span>
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'rating' | 'distance' | 'price' | 'popularity')}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            >
              <option value="rating">Rating</option>
              <option value="distance">Distance</option>
              <option value="price">Price</option>
              <option value="popularity">Popularity</option>
            </select>
          </div>
        </div>

        {/* Results Count with Enhanced Info */}
        <div className="flex items-center justify-between mb-6 bg-white rounded-lg p-4 shadow-sm">
          <div className="flex items-center space-x-2">
            <MapPin className="w-5 h-5 text-green-500" />
            <span className="text-gray-600">
              Showing {filteredRestaurants.length} restaurants near {preferences.location || 'your location'}
            </span>
          </div>
          <div className="flex items-center space-x-4 text-sm text-gray-500">
            <div className="flex items-center space-x-1">
              <Star className="w-4 h-4 text-yellow-500" />
              <span>Avg Rating: {(filteredRestaurants.reduce((sum, r) => sum + r.rating, 0) / filteredRestaurants.length).toFixed(1)}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Users className="w-4 h-4 text-blue-500" />
              <span>For {preferences.numberOfPeople} people</span>
            </div>
          </div>
        </div>

        {/* Restaurant Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredRestaurants.map((restaurant) => (
            <RestaurantCard
              key={restaurant.id}
              restaurant={restaurant}
              onGetDirections={onGetDirections}
            />
          ))}
        </div>

        {filteredRestaurants.length === 0 && (
          <div className="text-center py-12">
            <p className="text-xl text-gray-600">No restaurants match your current filters.</p>
            <button
              onClick={() => setFilterCount('all')}
              className="mt-4 text-orange-500 hover:text-orange-600 font-medium"
            >
              Show all results
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default EnhancedRecommendations;