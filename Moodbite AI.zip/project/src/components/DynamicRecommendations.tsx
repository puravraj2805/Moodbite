import React, { useState, useEffect, useMemo } from 'react';
import { Restaurant, UserPreferences } from '../types';
import RestaurantCard from './RestaurantCard';
import { Filter, SortAsc, MapPin, Star, TrendingUp, Users, Brain, Zap, Target } from 'lucide-react';
import useAIAgent from '../hooks/useAIAgent';

interface DynamicRecommendationsProps {
  preferences: UserPreferences;
  onGetDirections: (restaurant: Restaurant) => void;
  searchQuery?: string;
}

const DynamicRecommendations: React.FC<DynamicRecommendationsProps> = ({ 
  preferences, 
  onGetDirections,
  searchQuery = ''
}) => {
  const [filterCount, setFilterCount] = useState<'all' | 'top2' | 'top5' | 'top10' | 'top15' | 'top20'>('all');
  const [sortBy, setSortBy] = useState<'aiScore' | 'rating' | 'distance' | 'price' | 'popularity'>('aiScore');
  const [showSources, setShowSources] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [realTimeUpdates, setRealTimeUpdates] = useState(true);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  const { generateSmartRecommendations, contextMemory } = useAIAgent();

  // Generate intelligent recommendations
  const aiRecommendations = useMemo(() => {
    return generateSmartRecommendations(preferences);
  }, [preferences, generateSmartRecommendations]);

  // Simulate real-time AI analysis
  useEffect(() => {
    setIsAnalyzing(true);
    const analysisTimer = setTimeout(() => {
      setAnalysisComplete(true);
      setIsAnalyzing(false);
    }, 2500);

    return () => clearTimeout(analysisTimer);
  }, [preferences]);

  // Enhanced restaurant data with AI scoring
  const enhancedRestaurants: Restaurant[] = useMemo(() => {
    const baseRestaurants = [
      {
        id: '1',
        name: 'The Garden Bistro',
        rating: 4.8,
        cuisine: 'Mediterranean',
        priceRange: preferences.budget || '$$',
        address: '123 Main St, Downtown',
        image: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Outdoor Seating', 'Live Music', 'LGBTQ+ Friendly', 'Pet Friendly'],
        distance: '0.5 mi',
        estimatedTime: '15 min',
        phoneNumber: '(555) 123-4567',
        aiScore: 95,
        matchReasons: ['Perfect cuisine match', 'Ideal for your group size', 'Within budget range'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: This restaurant perfectly aligns with your preferences for ambience and outdoor dining!'
      },
      {
        id: '2',
        name: 'Spice Route',
        rating: 4.6,
        cuisine: 'Indian',
        priceRange: '$$$',
        address: '456 Oak Ave, Midtown',
        image: 'https://images.pexels.com/photos/1579739/pexels-photo-1579739.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Kids Menu', 'Good Drinks', 'Date Night', 'Authentic Spices'],
        distance: '1.2 mi',
        estimatedTime: '20 min',
        phoneNumber: '(555) 234-5678',
        aiScore: 88,
        matchReasons: ['Excellent for families', 'Great drink selection', 'Trending upward'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Rising popularity with authentic flavors that match your adventurous palette!'
      },
      {
        id: '3',
        name: 'Golden Dragon',
        rating: 4.7,
        cuisine: 'Chinese',
        priceRange: '$$',
        address: '234 Dragon St, Chinatown',
        image: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Authentic Chinese', 'Family Style', 'Fresh Ingredients', 'Dim Sum'],
        distance: '1.8 mi',
        estimatedTime: '23 min',
        aiScore: 90,
        matchReasons: ['Authentic Chinese cuisine', 'Perfect for groups', 'Traditional recipes'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Chinese restaurant with traditional flavors and excellent group dining!'
      },
      {
        id: '4',
        name: 'Taco Fiesta',
        rating: 4.5,
        cuisine: 'Mexican',
        priceRange: '$$',
        address: '567 Salsa Ave, Mexican Quarter',
        image: 'https://images.pexels.com/photos/4958792/pexels-photo-4958792.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Authentic Mexican', 'Fresh Guacamole', 'Margaritas', 'Family Friendly'],
        distance: '1.0 mi',
        estimatedTime: '17 min',
        aiScore: 87,
        matchReasons: ['Perfect Mexican cuisine', 'Great value', 'Festive atmosphere'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Vibrant Mexican restaurant with authentic flavors and lively atmosphere!'
      },
      {
        id: '5',
        name: 'Coastal Catch',
        rating: 4.7,
        cuisine: 'Seafood',
        priceRange: '$$$$',
        address: '789 Beach Rd, Waterfront',
        image: 'https://images.pexels.com/photos/696218/pexels-photo-696218.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Ocean View', 'Fresh Seafood', 'Romantic', 'Wine Pairing'],
        distance: '2.1 mi',
        estimatedTime: '25 min',
        phoneNumber: '(555) 345-6789',
        aiScore: 92,
        matchReasons: ['Premium dining experience', 'Perfect for special occasions', 'Stunning ambience'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: High-end option with exceptional ambience scoring - perfect for memorable experiences!'
      },
      {
        id: '6',
        name: 'Urban Eats',
        rating: 4.5,
        cuisine: 'American',
        priceRange: '$$',
        address: '321 City Plaza, Central',
        image: 'https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Family Friendly', 'Quick Service', 'All Ages', 'Local Favorite'],
        distance: '0.8 mi',
        estimatedTime: '18 min',
        phoneNumber: '(555) 456-7890',
        aiScore: 85,
        matchReasons: ['Great value proposition', 'Family-friendly atmosphere', 'Convenient location'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Excellent balance of quality and value, perfect for casual group dining!'
      },
      {
        id: '7',
        name: 'Sakura Sushi',
        rating: 4.9,
        cuisine: 'Japanese',
        priceRange: '$$$',
        address: '555 Cherry Ln, Uptown',
        image: 'https://images.pexels.com/photos/248444/pexels-photo-248444.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Fresh Sushi', 'Quiet Atmosphere', 'Chef\'s Table', 'Premium Ingredients'],
        distance: '1.5 mi',
        estimatedTime: '22 min',
        phoneNumber: '(555) 567-8901',
        aiScore: 94,
        matchReasons: ['Highest customer ratings', 'Premium ingredient quality', 'Intimate dining experience'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Top-rated for food quality with serene ambience - a hidden gem!'
      },
      {
        id: '8',
        name: 'Mama Mia Pizzeria',
        rating: 4.4,
        cuisine: 'Italian',
        priceRange: '$$',
        address: '777 Vine St, Little Italy',
        image: 'https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Wood Fired Pizza', 'Family Style', 'Kids Friendly', 'Traditional Recipes'],
        distance: '1.0 mi',
        estimatedTime: '19 min',
        phoneNumber: '(555) 678-9012',
        aiScore: 82,
        matchReasons: ['Authentic Italian cuisine', 'Great for families', 'Traditional cooking methods'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Classic Italian experience with time-tested recipes that never disappoint!'
      },
      {
        id: '9',
        name: 'Bangkok Spice',
        rating: 4.6,
        cuisine: 'Thai',
        priceRange: '$$$',
        address: '890 Thai Street, Asian District',
        image: 'https://images.pexels.com/photos/1410235/pexels-photo-1410235.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Authentic Thai', 'Spice Levels', 'Fresh Herbs', 'Vegetarian Options'],
        distance: '1.4 mi',
        estimatedTime: '21 min',
        aiScore: 89,
        matchReasons: ['Authentic Thai flavors', 'Customizable spice levels', 'Fresh ingredients'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Thai cuisine with perfect balance of flavors and heat!'
      }
      ,
      // Additional Italian Restaurants
      {
        id: '10',
        name: 'Romano\'s Kitchen',
        rating: 4.8,
        cuisine: 'Italian',
        priceRange: '$$$',
        address: '445 Roma Street, Little Italy',
        image: 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Homemade Pasta', 'Wine Cellar', 'Romantic', 'Date Night'],
        distance: '1.3 mi',
        estimatedTime: '20 min',
        aiScore: 91,
        matchReasons: ['Authentic Italian recipes', 'Perfect for romantic dinners', 'Excellent wine selection'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Italian with homemade pasta and romantic ambience!'
      },
      {
        id: '11',
        name: 'Nonna\'s Trattoria',
        rating: 4.5,
        cuisine: 'Italian',
        priceRange: '$$',
        address: '112 Florence Ave, Italian Quarter',
        image: 'https://images.pexels.com/photos/1109197/pexels-photo-1109197.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Family Recipes', 'Cozy Atmosphere', 'Fresh Ingredients', 'Traditional'],
        distance: '0.9 mi',
        estimatedTime: '16 min',
        aiScore: 86,
        matchReasons: ['Traditional family recipes', 'Cozy atmosphere', 'Great value'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Family-run Italian trattoria with generations-old recipes!'
      },
      // Additional Chinese Restaurants
      {
        id: '12',
        name: 'Peking Palace',
        rating: 4.7,
        cuisine: 'Chinese',
        priceRange: '$$$',
        address: '678 Beijing Road, Chinatown',
        image: 'https://images.pexels.com/photos/2347311/pexels-photo-2347311.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Peking Duck', 'Elegant Decor', 'Private Dining', 'Traditional Tea'],
        distance: '2.0 mi',
        estimatedTime: '24 min',
        phoneNumber: '(555) 789-0123',
        aiScore: 93,
        matchReasons: ['Famous for Peking Duck', 'Elegant dining experience', 'Traditional Chinese'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Upscale Chinese restaurant famous for authentic Peking Duck!'
      },
      {
        id: '13',
        name: 'Szechuan Garden',
        rating: 4.4,
        cuisine: 'Chinese',
        priceRange: '$$',
        address: '321 Spice Lane, Asian District',
        image: 'https://images.pexels.com/photos/1410236/pexels-photo-1410236.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Spicy Szechuan', 'Authentic Flavors', 'Hot Pot', 'Family Style'],
        distance: '1.6 mi',
        estimatedTime: '22 min',
        phoneNumber: '(555) 890-1234',
        aiScore: 88,
        matchReasons: ['Authentic Szechuan cuisine', 'Perfect spice levels', 'Great for groups'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Authentic Szechuan restaurant with perfect balance of heat and flavor!'
      },
      // Additional Indian Restaurants
      {
        id: '14',
        name: 'Tandoor Express',
        rating: 4.6,
        cuisine: 'Indian',
        priceRange: '$$',
        address: '789 Curry Street, Indian Quarter',
        image: 'https://images.pexels.com/photos/1633578/pexels-photo-1633578.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Tandoor Oven', 'Vegetarian Options', 'Naan Bread', 'Curry Specialties'],
        distance: '1.1 mi',
        estimatedTime: '19 min',
        aiScore: 89,
        matchReasons: ['Fresh tandoor cooking', 'Extensive vegetarian menu', 'Authentic spices'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Indian with fresh tandoor cooking and amazing vegetarian options!'
      },
      {
        id: '15',
        name: 'Mumbai Nights',
        rating: 4.8,
        cuisine: 'Indian',
        priceRange: '$$$',
        address: '456 Bollywood Ave, Spice District',
        image: 'https://images.pexels.com/photos/1640770/pexels-photo-1640770.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Street Food', 'Live Music', 'Bollywood Theme', 'Biryani Speciality'],
        distance: '1.8 mi',
        estimatedTime: '23 min',
        aiScore: 92,
        matchReasons: ['Authentic Mumbai street food', 'Entertaining atmosphere', 'Best biryani in town'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Vibrant Indian restaurant with authentic Mumbai street food experience!'
      },
      // Additional Mexican Restaurants
      {
        id: '16',
        name: 'Casa Rodriguez',
        rating: 4.7,
        cuisine: 'Mexican',
        priceRange: '$$$',
        address: '234 Mariachi Street, Mexican Quarter',
        image: 'https://images.pexels.com/photos/2092507/pexels-photo-2092507.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Live Mariachi', 'Premium Tequila', 'Authentic Mole', 'Upscale Mexican'],
        distance: '1.4 mi',
        estimatedTime: '21 min',
        phoneNumber: '(555) 901-2345',
        aiScore: 90,
        matchReasons: ['Upscale Mexican dining', 'Live entertainment', 'Premium ingredients'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Upscale Mexican restaurant with live mariachi and exceptional mole dishes!'
      },
      // New Cuisines
      {
        id: '17',
        name: 'Le Petit Bistro',
        rating: 4.9,
        cuisine: 'French',
        priceRange: '$$$$',
        address: '890 Paris Lane, French Quarter',
        image: 'https://images.pexels.com/photos/262047/pexels-photo-262047.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['French Cuisine', 'Wine Pairing', 'Intimate Setting', 'Chef\'s Table'],
        distance: '2.3 mi',
        estimatedTime: '27 min',
        aiScore: 96,
        matchReasons: ['Authentic French cuisine', 'Perfect for special occasions', 'Excellent wine selection'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Exquisite French bistro with chef-driven cuisine and perfect wine pairings!'
      },
      {
        id: '18',
        name: 'Seoul Kitchen',
        rating: 4.6,
        cuisine: 'Korean',
        priceRange: '$$',
        address: '567 Seoul Street, K-Town',
        image: 'https://images.pexels.com/photos/1647163/pexels-photo-1647163.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Korean BBQ', 'Kimchi Bar', 'K-Pop Music', 'Soju Selection'],
        distance: '1.7 mi',
        estimatedTime: '22 min',
        phoneNumber: '(555) 012-3456',
        aiScore: 87,
        matchReasons: ['Authentic Korean BBQ', 'Interactive dining', 'Cultural experience'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Korean restaurant with table-top BBQ and vibrant K-Pop atmosphere!'
      },
      {
        id: '19',
        name: 'Santorini Taverna',
        rating: 4.5,
        cuisine: 'Greek',
        priceRange: '$$$',
        address: '123 Athens Way, Mediterranean Quarter',
        image: 'https://images.pexels.com/photos/1640772/pexels-photo-1640772.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Greek Seafood', 'Outdoor Terrace', 'Live Greek Music', 'Ouzo Selection'],
        distance: '1.9 mi',
        estimatedTime: '24 min',
        phoneNumber: '(555) 123-5678',
        aiScore: 89,
        matchReasons: ['Fresh seafood', 'Mediterranean atmosphere', 'Authentic Greek flavors'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Beautiful Greek taverna with fresh seafood and Mediterranean charm!'
      },
      {
        id: '20',
        name: 'Copacabana Grill',
        rating: 4.4,
        cuisine: 'Brazilian',
        priceRange: '$$$',
        address: '777 Rio Avenue, Brazilian District',
        image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Churrasco', 'Salad Bar', 'Caipirinha', 'Live Samba'],
        distance: '2.1 mi',
        estimatedTime: '25 min',
        phoneNumber: '(555) 234-6789',
        aiScore: 88,
        matchReasons: ['All-you-can-eat meat', 'Festive atmosphere', 'Brazilian experience'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Brazilian churrascaria with endless grilled meats and samba music!'
      },
      {
        id: '21',
        name: 'Pho Saigon',
        rating: 4.7,
        cuisine: 'Vietnamese',
        priceRange: '$$',
        address: '345 Saigon Street, Vietnamese Quarter',
        image: 'https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Fresh Pho', 'Banh Mi', 'Fresh Herbs', 'Authentic Broth'],
        distance: '1.2 mi',
        estimatedTime: '19 min',
        phoneNumber: '(555) 345-7890',
        aiScore: 90,
        matchReasons: ['Authentic Vietnamese pho', 'Fresh ingredients', 'Great value'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Vietnamese restaurant with perfectly crafted pho and fresh herbs!'
      },
      {
        id: '22',
        name: 'Istanbul Nights',
        rating: 4.6,
        cuisine: 'Turkish',
        priceRange: '$$',
        address: '456 Ottoman Street, Middle Eastern Quarter',
        image: 'https://images.pexels.com/photos/1640775/pexels-photo-1640775.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Kebabs', 'Turkish Coffee', 'Baklava', 'Hookah Lounge'],
        distance: '1.6 mi',
        estimatedTime: '21 min',
        phoneNumber: '(555) 456-8901',
        aiScore: 87,
        matchReasons: ['Authentic Turkish cuisine', 'Cultural atmosphere', 'Great desserts'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Authentic Turkish restaurant with incredible kebabs and traditional atmosphere!'
      },
      {
        id: '23',
        name: 'Bavarian House',
        rating: 4.3,
        cuisine: 'German',
        priceRange: '$$',
        address: '789 Munich Way, German Quarter',
        image: 'https://images.pexels.com/photos/1640776/pexels-photo-1640776.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['German Beer', 'Oktoberfest Style', 'Sausages', 'Live Band'],
        distance: '2.0 mi',
        estimatedTime: '24 min',
        phoneNumber: '(555) 567-9012',
        aiScore: 85,
        matchReasons: ['Authentic German cuisine', 'Great beer selection', 'Fun atmosphere'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Traditional German restaurant with authentic beer hall atmosphere!'
      },
      {
        id: '24',
        name: 'Barcelona Tapas',
        rating: 4.8,
        cuisine: 'Spanish',
        priceRange: '$$$',
        address: '234 Barcelona Street, Spanish Quarter',
        image: 'https://images.pexels.com/photos/1640773/pexels-photo-1640773.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Tapas Selection', 'Sangria', 'Paella', 'Flamenco Shows'],
        distance: '1.8 mi',
        estimatedTime: '23 min',
        phoneNumber: '(555) 678-0123',
        aiScore: 91,
        matchReasons: ['Authentic Spanish tapas', 'Great for sharing', 'Vibrant atmosphere'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Vibrant Spanish tapas bar with authentic paella and flamenco entertainment!'
      },
      {
        id: '25',
        name: 'Tokyo Ramen House',
        rating: 4.7,
        cuisine: 'Japanese',
        priceRange: '$$',
        address: '678 Tokyo Street, Japan Town',
        image: 'https://images.pexels.com/photos/1640771/pexels-photo-1640771.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Authentic Ramen', 'Japanese Beer', 'Counter Seating', 'Fresh Noodles'],
        distance: '1.3 mi',
        estimatedTime: '20 min',
        phoneNumber: '(555) 789-1234',
        aiScore: 89,
        matchReasons: ['Authentic ramen experience', 'Made-to-order noodles', 'Casual atmosphere'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Japanese ramen house with handmade noodles and rich broths!'
      },
      {
        id: '26',
        name: 'Ethiopian Highlands',
        rating: 4.4,
        cuisine: 'Ethiopian',
        priceRange: '$$',
        address: '890 Addis Street, African Quarter',
        image: 'https://images.pexels.com/photos/1640778/pexels-photo-1640778.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Injera Bread', 'Vegetarian Options', 'Communal Dining', 'Coffee Ceremony'],
        distance: '2.2 mi',
        estimatedTime: '26 min',
        phoneNumber: '(555) 890-2345',
        aiScore: 86,
        matchReasons: ['Unique dining experience', 'Healthy options', 'Cultural immersion'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Ethiopian restaurant with traditional communal dining and rich spices!'
      },
      {
        id: '27',
        name: 'Havana Nights',
        rating: 4.5,
        cuisine: 'Cuban',
        priceRange: '$$',
        address: '345 Havana Avenue, Cuban Quarter',
        image: 'https://images.pexels.com/photos/1640779/pexels-photo-1640779.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Cuban Sandwich', 'Mojitos', 'Live Salsa', 'Plantains'],
        distance: '1.5 mi',
        estimatedTime: '21 min',
        phoneNumber: '(555) 901-3456',
        aiScore: 88,
        matchReasons: ['Authentic Cuban flavors', 'Lively atmosphere', 'Great cocktails'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Vibrant Cuban restaurant with live salsa music and authentic island flavors!'
      }
    ];

    // Strict filtering - only show restaurants that match selected cuisine exactly
    let filteredByPreference = baseRestaurants;
    if (preferences.foodType) {
      filteredByPreference = baseRestaurants.filter(restaurant => 
        restaurant.cuisine.toLowerCase() === preferences.foodType?.toLowerCase()
      );
    }

    // Additional restaurants for comprehensive catalog
    const expandedRestaurants = [
      ...filteredByPreference,
      // More Asian Cuisines
      {
        id: '28',
        name: 'Manila Bay Filipino',
        rating: 4.6,
        cuisine: 'Filipino',
        priceRange: '$$',
        address: '123 Kamayan Street, Filipino Quarter',
        image: 'https://images.pexels.com/photos/1640780/pexels-photo-1640780.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Kamayan Style', 'Lechon', 'Halo-Halo', 'Family Portions'],
        distance: '1.4 mi',
        estimatedTime: '20 min',
        phoneNumber: '(555) 012-4567',
        aiScore: 88,
        matchReasons: ['Authentic Filipino cuisine', 'Family-style dining', 'Unique flavors'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Filipino restaurant with traditional kamayan dining experience!'
      },
      {
        id: '29',
        name: 'Jakarta Spice House',
        rating: 4.5,
        cuisine: 'Indonesian',
        priceRange: '$$',
        address: '456 Bali Street, Indonesian Quarter',
        image: 'https://images.pexels.com/photos/1640781/pexels-photo-1640781.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Rendang', 'Nasi Goreng', 'Spice Blends', 'Tropical Atmosphere'],
        distance: '1.6 mi',
        estimatedTime: '22 min',
        phoneNumber: '(555) 123-6789',
        aiScore: 89,
        matchReasons: ['Rich spice flavors', 'Tropical island vibes', 'Authentic recipes'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Indonesian restaurant with complex spice blends and island atmosphere!'
      },
      {
        id: '30',
        name: 'Himalayan Kitchen',
        rating: 4.4,
        cuisine: 'Nepalese',
        priceRange: '$$',
        address: '789 Everest Avenue, Mountain Quarter',
        image: 'https://images.pexels.com/photos/1640782/pexels-photo-1640782.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Momos', 'Dal Bhat', 'Mountain Views', 'Sherpa Culture'],
        distance: '2.0 mi',
        estimatedTime: '24 min',
        phoneNumber: '(555) 234-7890',
        aiScore: 87,
        matchReasons: ['Unique Himalayan cuisine', 'Cultural experience', 'Comfort food'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Authentic Nepalese restaurant with mountain-inspired comfort food!'
      },
      {
        id: '31',
        name: 'Sri Lankan Curry House',
        rating: 4.7,
        cuisine: 'Sri Lankan',
        priceRange: '$$',
        address: '234 Ceylon Street, Spice District',
        image: 'https://images.pexels.com/photos/1640783/pexels-photo-1640783.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Hoppers', 'String Hoppers', 'Fish Curry', 'Coconut Sambol'],
        distance: '1.8 mi',
        estimatedTime: '23 min',
        phoneNumber: '(555) 345-8901',
        aiScore: 90,
        matchReasons: ['Unique Sri Lankan flavors', 'Coconut-based curries', 'Island spices'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Authentic Sri Lankan restaurant with island-style curries and hoppers!'
      },
      // Middle Eastern & Persian
      {
        id: '32',
        name: 'Persian Palace',
        rating: 4.8,
        cuisine: 'Persian',
        priceRange: '$$$',
        address: '567 Isfahan Lane, Persian Quarter',
        image: 'https://images.pexels.com/photos/1640784/pexels-photo-1640784.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Saffron Rice', 'Kebab Koobideh', 'Persian Rugs', 'Live Tar Music'],
        distance: '1.9 mi',
        estimatedTime: '24 min',
        phoneNumber: '(555) 456-9012',
        aiScore: 93,
        matchReasons: ['Luxurious Persian dining', 'Live traditional music', 'Premium ingredients'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Elegant Persian restaurant with saffron-infused dishes and cultural ambience!'
      },
      {
        id: '33',
        name: 'Beirut Nights',
        rating: 4.6,
        cuisine: 'Lebanese',
        priceRange: '$$',
        address: '890 Cedar Street, Lebanese Quarter',
        image: 'https://images.pexels.com/photos/1640785/pexels-photo-1640785.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Mezze Platters', 'Shawarma', 'Oud Music', 'Hookah Lounge'],
        distance: '1.5 mi',
        estimatedTime: '21 min',
        phoneNumber: '(555) 567-0123',
        aiScore: 89,
        matchReasons: ['Authentic Lebanese mezze', 'Social dining experience', 'Mediterranean flavors'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Authentic Lebanese restaurant perfect for sharing mezze and socializing!'
      },
      {
        id: '34',
        name: 'Marrakech Express',
        rating: 4.5,
        cuisine: 'Moroccan',
        priceRange: '$$',
        address: '345 Marrakech Way, Moroccan Quarter',
        image: 'https://images.pexels.com/photos/1640786/pexels-photo-1640786.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Tagine', 'Couscous', 'Mint Tea', 'Moroccan Decor'],
        distance: '2.1 mi',
        estimatedTime: '25 min',
        phoneNumber: '(555) 678-1234',
        aiScore: 88,
        matchReasons: ['Authentic tagine dishes', 'Exotic spice blends', 'Cultural atmosphere'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Moroccan restaurant with authentic tagines and North African spices!'
      },
      {
        id: '35',
        name: 'Jerusalem Garden',
        rating: 4.4,
        cuisine: 'Israeli',
        priceRange: '$$',
        address: '678 Olive Branch Street, Middle East Quarter',
        image: 'https://images.pexels.com/photos/1640787/pexels-photo-1640787.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Shakshuka', 'Falafel', 'Fresh Pita', 'Mediterranean Garden'],
        distance: '1.7 mi',
        estimatedTime: '22 min',
        phoneNumber: '(555) 789-2345',
        aiScore: 86,
        matchReasons: ['Fresh Mediterranean ingredients', 'Healthy options', 'Garden setting'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Israeli restaurant with fresh Mediterranean flavors and garden atmosphere!'
      },
      // Latin American Expansion
      {
        id: '36',
        name: 'Lima Heights',
        rating: 4.9,
        cuisine: 'Peruvian',
        priceRange: '$$$',
        address: '123 Machu Picchu Drive, Peruvian Quarter',
        image: 'https://images.pexels.com/photos/1640788/pexels-photo-1640788.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Ceviche', 'Pisco Sour', 'Inca Cuisine', 'Fine Dining'],
        distance: '2.2 mi',
        estimatedTime: '26 min',
        phoneNumber: '(555) 890-3456',
        aiScore: 96,
        matchReasons: ['World-renowned ceviche', 'Unique Andean flavors', 'Fine dining experience'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Exceptional Peruvian restaurant with world-class ceviche and Inca-inspired dishes!'
      },
      {
        id: '37',
        name: 'Buenos Aires Grill',
        rating: 4.7,
        cuisine: 'Argentine',
        priceRange: '$$$',
        address: '456 Tango Street, Argentine Quarter',
        image: 'https://images.pexels.com/photos/1640789/pexels-photo-1640789.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Asado BBQ', 'Malbec Wine', 'Tango Shows', 'Premium Steaks'],
        distance: '1.8 mi',
        estimatedTime: '23 min',
        phoneNumber: '(555) 901-4567',
        aiScore: 94,
        matchReasons: ['Premium Argentine beef', 'Authentic asado experience', 'Tango entertainment'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Premium Argentine steakhouse with authentic asado and tango atmosphere!'
      },
      {
        id: '38',
        name: 'Bogota Coffee & Grill',
        rating: 4.5,
        cuisine: 'Colombian',
        priceRange: '$$',
        address: '789 Emerald Avenue, Colombian Quarter',
        image: 'https://images.pexels.com/photos/1640790/pexels-photo-1640790.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Arepas', 'Colombian Coffee', 'Vallenato Music', 'Casual Dining'],
        distance: '1.6 mi',
        estimatedTime: '21 min',
        phoneNumber: '(555) 012-5678',
        aiScore: 87,
        matchReasons: ['Authentic Colombian cuisine', 'Best coffee in town', 'Lively atmosphere'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Colombian restaurant with exceptional coffee and traditional arepas!'
      },
      {
        id: '39',
        name: 'Caracas Kitchen',
        rating: 4.3,
        cuisine: 'Venezuelan',
        priceRange: '$$',
        address: '234 Venezuela Way, South American Quarter',
        image: 'https://images.pexels.com/photos/1640791/pexels-photo-1640791.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Arepas', 'Pabellon Criollo', 'Cachapas', 'Family Style'],
        distance: '1.9 mi',
        estimatedTime: '24 min',
        phoneNumber: '(555) 123-7890',
        aiScore: 85,
        matchReasons: ['Authentic Venezuelan arepas', 'Family recipes', 'Comfort food'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Venezuelan restaurant with traditional arepas and family-style comfort food!'
      },
      // More African Cuisines
      {
        id: '40',
        name: 'Cape Town Braai',
        rating: 4.6,
        cuisine: 'South African',
        priceRange: '$$',
        address: '567 Safari Street, African Quarter',
        image: 'https://images.pexels.com/photos/1640792/pexels-photo-1640792.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Braai BBQ', 'Boerewors', 'Malva Pudding', 'African Decor'],
        distance: '2.0 mi',
        estimatedTime: '24 min',
        phoneNumber: '(555) 234-8901',
        aiScore: 88,
        matchReasons: ['Unique South African BBQ', 'African atmosphere', 'Traditional recipes'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: South African restaurant with authentic braai experience and African atmosphere!'
      },
      {
        id: '41',
        name: 'Lagos Kitchen',
        rating: 4.4,
        cuisine: 'Nigerian',
        priceRange: '$$',
        address: '890 Nollywood Drive, West African Quarter',
        image: 'https://images.pexels.com/photos/1640793/pexels-photo-1640793.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Jollof Rice', 'Egusi Soup', 'Suya', 'Afrobeats Music'],
        distance: '1.7 mi',
        estimatedTime: '22 min',
        phoneNumber: '(555) 345-9012',
        aiScore: 86,
        matchReasons: ['Authentic West African cuisine', 'Vibrant atmosphere', 'Spiced grilled meats'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Nigerian restaurant with authentic jollof rice and vibrant Afrobeats atmosphere!'
      },
      // More European Cuisines
      {
        id: '42',
        name: 'Prague Castle Restaurant',
        rating: 4.5,
        cuisine: 'Czech',
        priceRange: '$$',
        address: '345 Bohemia Street, Czech Quarter',
        image: 'https://images.pexels.com/photos/1640794/pexels-photo-1640794.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Goulash', 'Czech Beer', 'Dumplings', 'Traditional Decor'],
        distance: '1.8 mi',
        estimatedTime: '23 min',
        phoneNumber: '(555) 456-0123',
        aiScore: 87,
        matchReasons: ['Authentic Czech cuisine', 'Excellent beer selection', 'Hearty comfort food'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Czech restaurant with traditional goulash and exceptional beer selection!'
      },
      {
        id: '43',
        name: 'Budapest Bites',
        rating: 4.6,
        cuisine: 'Hungarian',
        priceRange: '$$',
        address: '678 Danube Street, Hungarian Quarter',
        image: 'https://images.pexels.com/photos/1640795/pexels-photo-1640795.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Paprikash', 'Schnitzel', 'Hungarian Wine', 'Folk Music'],
        distance: '1.5 mi',
        estimatedTime: '21 min',
        phoneNumber: '(555) 567-1234',
        aiScore: 88,
        matchReasons: ['Rich Hungarian flavors', 'Traditional paprika dishes', 'Cultural atmosphere'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Hungarian restaurant with authentic paprikash and folk music ambience!'
      },
      {
        id: '44',
        name: 'Amsterdam Cafe',
        rating: 4.4,
        cuisine: 'Dutch',
        priceRange: '$$',
        address: '123 Tulip Lane, Dutch Quarter',
        image: 'https://images.pexels.com/photos/1640796/pexels-photo-1640796.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Stroopwafels', 'Dutch Cheese', 'Cafe Culture', 'Canal Views'],
        distance: '1.4 mi',
        estimatedTime: '20 min',
        phoneNumber: '(555) 678-2345',
        aiScore: 85,
        matchReasons: ['Authentic Dutch cafe culture', 'Premium cheese selection', 'Canal-side dining'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Dutch cafe with authentic stroopwafels and canal-side atmosphere!'
      },
      {
        id: '45',
        name: 'Stockholm Nordic',
        rating: 4.8,
        cuisine: 'Scandinavian',
        priceRange: '$$$',
        address: '456 Viking Road, Nordic Quarter',
        image: 'https://images.pexels.com/photos/1640797/pexels-photo-1640797.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Nordic Cuisine', 'Foraging Menu', 'Aquavit', 'Minimalist Design'],
        distance: '2.1 mi',
        estimatedTime: '25 min',
        phoneNumber: '(555) 789-3456',
        aiScore: 93,
        matchReasons: ['Modern Nordic cuisine', 'Foraged ingredients', 'Scandinavian design'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Modern Scandinavian restaurant with foraged ingredients and Nordic design!'
      },
      {
        id: '46',
        name: 'Lisbon Seafood House',
        rating: 4.7,
        cuisine: 'Portuguese',
        priceRange: '$$$',
        address: '789 Porto Street, Portuguese Quarter',
        image: 'https://images.pexels.com/photos/1640798/pexels-photo-1640798.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Fresh Seafood', 'Pastéis de Nata', 'Port Wine', 'Ocean Views'],
        distance: '2.3 mi',
        estimatedTime: '27 min',
        phoneNumber: '(555) 890-4567',
        aiScore: 92,
        matchReasons: ['Fresh Atlantic seafood', 'Authentic Portuguese pastries', 'Ocean views'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Portuguese seafood restaurant with ocean-fresh catches and traditional pastries!'
      },
      // Fusion and Modern Cuisines
      {
        id: '47',
        name: 'Pacific Rim Fusion',
        rating: 4.6,
        cuisine: 'Pacific Rim',
        priceRange: '$$$',
        address: '234 Fusion Boulevard, Modern Quarter',
        image: 'https://images.pexels.com/photos/1640799/pexels-photo-1640799.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Asian-Pacific Fusion', 'Modern Plating', 'Craft Cocktails', 'Ocean Views'],
        distance: '1.9 mi',
        estimatedTime: '24 min',
        phoneNumber: '(555) 901-5678',
        aiScore: 90,
        matchReasons: ['Innovative fusion cuisine', 'Beautiful presentation', 'Creative flavors'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Pacific Rim fusion with innovative dishes blending Asian and Pacific flavors!'
      },
      {
        id: '48',
        name: 'Plant-Based Paradise',
        rating: 4.8,
        cuisine: 'Vegan',
        priceRange: '$$',
        address: '567 Green Garden Way, Eco Quarter',
        image: 'https://images.pexels.com/photos/1640800/pexels-photo-1640800.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['100% Plant-Based', 'Organic Ingredients', 'Raw Options', 'Eco-Friendly'],
        distance: '1.6 mi',
        estimatedTime: '21 min',
        phoneNumber: '(555) 012-6789',
        aiScore: 91,
        matchReasons: ['Innovative plant-based cuisine', 'Health-conscious options', 'Sustainable dining'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Exceptional vegan restaurant with creative plant-based dishes and eco-conscious dining!'
      },
      // More Specialty Restaurants
      {
        id: '49',
        name: 'The Smokehouse',
        rating: 4.5,
        cuisine: 'BBQ',
        priceRange: '$$',
        address: '890 Pit Master Lane, BBQ District',
        image: 'https://images.pexels.com/photos/1640801/pexels-photo-1640801.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Slow-Smoked Meats', 'House Rubs', 'Craft Beer', 'Outdoor Seating'],
        distance: '1.3 mi',
        estimatedTime: '19 min',
        phoneNumber: '(555) 123-8901',
        aiScore: 89,
        matchReasons: ['Authentic BBQ smoking', 'House-made rubs', 'Casual atmosphere'],
        popularityTrend: 'stable' as const,
        aiInsights: 'AI Analysis: Authentic BBQ smokehouse with slow-smoked meats and signature rubs!'
      },
      {
        id: '50',
        name: 'Ocean\'s Bounty',
        rating: 4.9,
        cuisine: 'Seafood',
        priceRange: '$$$$',
        address: '345 Harbor View, Waterfront District',
        image: 'https://images.pexels.com/photos/1640802/pexels-photo-1640802.jpeg?auto=compress&cs=tinysrgb&w=400',
        features: ['Daily Fresh Catch', 'Raw Bar', 'Wine Pairing', 'Harbor Views'],
        distance: '2.4 mi',
        estimatedTime: '28 min',
        phoneNumber: '(555) 234-9012',
        aiScore: 97,
        matchReasons: ['Premium fresh seafood', 'Harbor views', 'Fine dining experience'],
        popularityTrend: 'up' as const,
        aiInsights: 'AI Analysis: Premium seafood restaurant with daily fresh catches and stunning harbor views!'
      }
    ];

    // Filter based on preferences
    if (preferences.foodType) {
      return expandedRestaurants.filter(restaurant => 
        restaurant.cuisine.toLowerCase() === preferences.foodType?.toLowerCase()
      );
    }
    
    // Apply AI-enhanced scoring based on preferences
    return expandedRestaurants.map(restaurant => {
      let enhancedScore = restaurant.aiScore || restaurant.rating * 10;
      
      // Boost score based on preferences
      if (restaurant.cuisine.toLowerCase() === preferences.foodType?.toLowerCase()) enhancedScore += 20;
      if (restaurant.priceRange === preferences.budget) enhancedScore += 10;
      if (preferences.kidsFriendly && restaurant.features.some(f => f.toLowerCase().includes('kid'))) enhancedScore += 8;
      if (preferences.petFriendly && restaurant.features.some(f => f.toLowerCase().includes('pet'))) enhancedScore += 8;
      if (preferences.lgbtqFriendly && restaurant.features.some(f => f.toLowerCase().includes('lgbtq'))) enhancedScore += 8;
      if (preferences.priorityPreference === 'ambience' && restaurant.features.some(f => 
        ['romantic', 'view', 'atmosphere', 'outdoor', 'ambience'].some(keyword => f.toLowerCase().includes(keyword))
      )) enhancedScore += 12;
      if (preferences.priorityPreference === 'food' && restaurant.rating >= 4.5) enhancedScore += 12;

      return {
        ...restaurant,
        aiScore: Math.min(100, enhancedScore)
      };
    });
  }, [preferences]);

  const getFilteredRestaurants = () => {
    let filtered = [...enhancedRestaurants];

    // Sort restaurants
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'aiScore':
          return (b.aiScore || 0) - (a.aiScore || 0);
        case 'rating':
          return b.rating - a.rating;
        case 'distance':
          return parseFloat(a.distance) - parseFloat(b.distance);
        case 'price':
          return a.priceRange.length - b.priceRange.length;
        case 'popularity':
          const getPopularityScore = (restaurant: Restaurant) => {
            let score = restaurant.rating * 10;
            if (restaurant.popularityTrend === 'up') score += 10;
            return score;
          };
          return getPopularityScore(b) - getPopularityScore(a);
        default:
          return 0;
      }
    });

    // Apply filter count
    if (filterCount === 'top2') {
      filtered = filtered.slice(0, 2);
    } else if (filterCount === 'top5') {
      filtered = filtered.slice(0, 5);
    } else if (filterCount === 'top10') {
      filtered = filtered.slice(0, Math.min(10, filtered.length));
    } else if (filterCount === 'top15') {
      filtered = filtered.slice(0, 15);
    } else if (filterCount === 'top20') {
      filtered = filtered.slice(0, 20);
    }

    return filtered;
  };

  const filteredRestaurants = getFilteredRestaurants();

  return (
    <section id="recommendations" className="py-16 bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50">
      <div className="container mx-auto px-4">
        {/* AI Analysis Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className={`p-4 rounded-full ${isAnalyzing ? 'animate-spin bg-gradient-to-r from-purple-500 to-blue-500' : 'bg-gradient-to-r from-green-500 to-emerald-500'}`}>
              {isAnalyzing ? <Zap className="w-8 h-8 text-white" /> : <Target className="w-8 h-8 text-white" />}
            </div>
          </div>

          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            {isAnalyzing ? 'AI is Analyzing Your Perfect Match...' : 'Perfect Matches Found! 🎯'}
          </h2>
          
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-6">
            {isAnalyzing ? 
              'Processing your preferences with advanced algorithms...' :
              `Based on your preferences for ${preferences.occasion || 'dining'} with ${preferences.numberOfPeople} people`
            }
          </p>

          {analysisComplete && (
            <div className="bg-white rounded-xl p-6 shadow-lg max-w-4xl mx-auto mb-8">
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Brain className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="font-semibold text-gray-800">AI Match Score</h4>
                  <p className="text-2xl font-bold text-green-600">{filteredRestaurants[0]?.aiScore || 0}%</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-400 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Star className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="font-semibold text-gray-800">Average Rating</h4>
                  <p className="text-2xl font-bold text-blue-600">
                    {(filteredRestaurants.reduce((sum, r) => sum + r.rating, 0) / filteredRestaurants.length).toFixed(1)}
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="font-semibold text-gray-800">Trending Up</h4>
                  <p className="text-2xl font-bold text-purple-600">
                    {filteredRestaurants.filter(r => r.popularityTrend === 'up').length}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Real-time Updates Toggle */}
          <div className="flex justify-center mb-6">
            <button
              onClick={() => setRealTimeUpdates(!realTimeUpdates)}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                realTimeUpdates 
                  ? 'bg-green-500 text-white shadow-lg' 
                  : 'bg-gray-200 text-gray-600'
              }`}
            >
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${realTimeUpdates ? 'bg-white animate-pulse' : 'bg-gray-400'}`}></div>
                <span>Real-time AI Updates</span>
              </div>
            </button>
          </div>
        </div>

        {/* Enhanced Controls */}
        <div className="flex flex-wrap justify-between items-center mb-8 bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center space-x-4 mb-4 sm:mb-0">
            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-gray-600" />
              <span className="font-medium text-gray-700">Show:</span>
            </div>
            <select
              value={filterCount}
              onChange={(e) => setFilterCount(e.target.value as 'all' | 'top2' | 'top5' | 'top10' | 'top15' | 'top20')}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300"
            >
              <option value="all">All AI Matches</option>
              <option value="top2">Top 2 Recommendations</option>
              <option value="top5">Top 5 Picks</option>
              <option value="top10">Top 10 Results</option>
              <option value="top15">Top 15 Options</option>
              <option value="top20">Top 20 Choices</option>
            </select>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <SortAsc className="w-5 h-5 text-gray-600" />
              <span className="font-medium text-gray-700">Sort by:</span>
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'aiScore' | 'rating' | 'distance' | 'price' | 'popularity')}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300"
            >
              <option value="aiScore">🧠 AI Match Score</option>
              <option value="rating">⭐ Rating</option>
              <option value="distance">📍 Distance</option>
              <option value="price">💰 Price</option>
              <option value="popularity">📈 Popularity</option>
            </select>
          </div>
        </div>

        {/* Results Info with AI Insights */}
        <div className="flex items-center justify-between mb-6 bg-white rounded-lg p-4 shadow-sm">
          <div className="flex items-center space-x-2">
            <MapPin className="w-5 h-5 text-green-500" />
            <span className="text-gray-600">
              Showing {filteredRestaurants.length} AI-powered matches 
              {searchQuery && <span className="text-purple-600 font-medium"> for "{searchQuery}"</span>}
              {!searchQuery && <span> near {preferences.location || 'your location'}</span>}
            </span>
          </div>
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-1 bg-purple-100 px-3 py-1 rounded-full">
              <Brain className="w-4 h-4 text-purple-600" />
              <span className="text-purple-700 font-medium">AI Powered</span>
            </div>
            <div className="flex items-center space-x-1">
              <Users className="w-4 h-4 text-blue-500" />
              <span className="text-gray-600">For {preferences.numberOfPeople} people</span>
            </div>
          </div>
        </div>

        {/* Restaurant Grid with Loading States */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isAnalyzing ? (
            // Loading skeletons
            Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden animate-pulse">
                <div className="h-48 bg-gray-300"></div>
                <div className="p-6 space-y-3">
                  <div className="h-4 bg-gray-300 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-300 rounded w-1/2"></div>
                  <div className="h-3 bg-gray-300 rounded w-full"></div>
                </div>
              </div>
            ))
          ) : (
            filteredRestaurants.map((restaurant, index) => (
              <div 
                key={restaurant.id} 
                className="transform transition-all duration-300 hover:scale-105"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <RestaurantCard
                  restaurant={restaurant}
                  onGetDirections={onGetDirections}
                />
              </div>
            ))
          )}
        </div>

        {!isAnalyzing && filteredRestaurants.length === 0 && (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
              <Brain className="w-12 h-12 text-gray-400" />
            </div>
            <p className="text-xl text-gray-600 mb-4">No restaurants match your current filters.</p>
            <button
              onClick={() => setFilterCount('all')}
              className="bg-gradient-to-r from-purple-500 to-blue-500 text-white px-6 py-2 rounded-lg hover:from-purple-600 hover:to-blue-600 transition-all duration-300"
            >
              Show all AI matches
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default DynamicRecommendations;